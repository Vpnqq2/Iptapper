package com.example

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdManager
import com.example.ads.ConsentManager
import com.example.core.logs.LogManager
import com.example.data.model.ConnectionState
import com.example.data.model.TunnelConfig
import com.example.ui.components.BottomNavBar
import com.example.ui.components.NavTab
import com.example.ui.screens.AddEditConfigScreen
import com.example.ui.screens.ConfigsListScreen
import com.example.ui.screens.ConnectionDetailsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LogsScreen
import com.example.ui.screens.AnimatedSplash
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TapHomeScreen
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.SshTunnelTheme
import com.example.ui.viewmodel.MainViewModel

sealed class AppDestination {
    object Main : AppDestination()
    data class AddEdit(val configToEdit: TunnelConfig? = null) : AppDestination()
    object Settings : AppDestination()
    object ConnectionDetails : AppDestination()
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Ask for ad consent where required, then start AdMob
        ConsentManager.gather(this) { AdManager.init(this) }

        setContent {
            SshTunnelTheme {
                val context = LocalContext.current

                val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
                val selectedConfig by viewModel.selectedConfig.collectAsStateWithLifecycle()
                val activeConfig by viewModel.activeConfig.collectAsStateWithLifecycle()
                val allConfigs by viewModel.allConfigs.collectAsStateWithLifecycle()
                val trafficStats by viewModel.trafficStats.collectAsStateWithLifecycle()
                val logs by viewModel.logs.collectAsStateWithLifecycle()
                val settings by viewModel.settings.collectAsStateWithLifecycle()
                val fetching by viewModel.fetching.collectAsStateWithLifecycle()
                val fetchError by viewModel.error.collectAsStateWithLifecycle()
                val serverInfo by viewModel.serverInfo.collectAsStateWithLifecycle()

                // Hidden advanced mode (long-press the title): the old config / logs / settings screens.
                var advanced by remember { mutableStateOf(false) }

                var currentTab by remember { mutableStateOf(NavTab.HOME) }
                var currentDestination by remember { mutableStateOf<AppDestination>(AppDestination.Main) }

                var showSplash by remember { mutableStateOf(true) }

                // Interstitial ad right after a connection succeeds (not when the app opens already connected)
                val isConnected = connectionState is ConnectionState.Connected
                var wasConnected by remember { mutableStateOf(isConnected) }
                LaunchedEffect(isConnected) {
                    if (isConnected && !wasConnected &&
                        lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
                    ) {
                        AdManager.showInterstitial(this@MainActivity)
                    }
                    wasConnected = isConnected
                }

                // Notification permission launcher (Android 13+)
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    if (!isGranted) {
                        LogManager.w("Notification permission not granted. Foreground status will not be visible in notification shade.")
                    }
                }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                // VPN Consent launcher
                var pendingConfigToConnect by remember { mutableStateOf<TunnelConfig?>(null) }
                val vpnConsentLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    if (result.resultCode == Activity.RESULT_OK) {
                        viewModel.connect(context, pendingConfigToConnect)
                    } else {
                        LogManager.e("VPN permission was denied by user")
                    }
                    pendingConfigToConnect = null
                }

                fun requestConnect(config: TunnelConfig?) {
                    val target = config ?: selectedConfig ?: allConfigs.firstOrNull()
                    if (target == null) {
                        currentDestination = AppDestination.AddEdit()
                        return
                    }

                    val prepareIntent = VpnService.prepare(context)
                    if (prepareIntent != null) {
                        pendingConfigToConnect = target
                        vpnConsentLauncher.launch(prepareIntent)
                    } else {
                        viewModel.connect(context, target)
                    }
                }

                // Handle system back navigation
                BackHandler(enabled = currentDestination !is AppDestination.Main || currentTab != NavTab.HOME || advanced) {
                    when {
                        currentDestination !is AppDestination.Main -> {
                            currentDestination = AppDestination.Main
                        }
                        currentTab != NavTab.HOME -> {
                            currentTab = NavTab.HOME
                        }
                        advanced -> advanced = false
                    }
                }

                Box(Modifier.fillMaxSize()) {
                when (val dest = currentDestination) {
                    is AppDestination.AddEdit -> {
                        val editConfig = dest.configToEdit
                        val initialSshPass = if (editConfig != null) viewModel.decryptPassword(editConfig.sshPasswordEncrypted) else ""
                        val initialProxyPass = if (editConfig != null) viewModel.decryptPassword(editConfig.proxyPasswordEncrypted) else ""

                        AddEditConfigScreen(
                            initialConfig = editConfig,
                            initialDecryptedSshPass = initialSshPass,
                            initialDecryptedProxyPass = initialProxyPass,
                            onSave = { config, rawSsh, rawProxy ->
                                viewModel.saveConfig(config, rawSsh, rawProxy) {
                                    currentDestination = AppDestination.Main
                                }
                            },
                            onBack = { currentDestination = AppDestination.Main }
                        )
                    }
                    is AppDestination.Settings -> {
                        SettingsScreen(
                            settings = settings,
                            onUpdateSettings = { viewModel.updateSettings(it) },
                            onBack = { currentDestination = AppDestination.Main }
                        )
                    }
                    is AppDestination.ConnectionDetails -> {
                        ConnectionDetailsScreen(
                            config = activeConfig ?: selectedConfig,
                            trafficStats = trafficStats,
                            connectionState = connectionState,
                            onBack = { currentDestination = AppDestination.Main }
                        )
                    }
                    is AppDestination.Main -> if (!advanced) {
                        TapHomeScreen(
                            appNameLight = "IP",
                            appNameAccent = "TAPPER",
                            connectionState = connectionState,
                            fetching = fetching,
                            error = fetchError,
                            countryCode = serverInfo?.countryCode,
                            ip = serverInfo?.ip,
                            flagUrl = serverInfo?.flagUrl,
                            onConnect = { viewModel.pickRandomServer { cfg -> requestConnect(cfg) } },
                            onDisconnect = { viewModel.disconnect(context) },
                            onTitleLongPress = { advanced = true }
                        )
                    } else {
                        Scaffold(
                            containerColor = DarkNavyBg,
                            contentWindowInsets = WindowInsets(0, 0, 0, 0),
                            bottomBar = {
                                BottomNavBar(
                                    selectedTab = currentTab,
                                    onTabSelected = { tab ->
                                        currentTab = tab
                                    }
                                )
                            }
                        ) { paddingValues ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(bottom = paddingValues.calculateBottomPadding())
                                    .background(DarkNavyBg)
                            ) {
                                when (currentTab) {
                                    NavTab.HOME -> {
                                        HomeScreen(
                                            connectionState = connectionState,
                                            selectedConfig = selectedConfig ?: allConfigs.firstOrNull(),
                                            trafficStats = trafficStats,
                                            onConnectClicked = { requestConnect(selectedConfig) },
                                            onDisconnectClicked = { viewModel.disconnect(context) },
                                            onConfigCardClicked = { currentTab = NavTab.CONFIGS },
                                            onSettingsClicked = { currentDestination = AppDestination.Settings },
                                            onServerCardClicked = { currentDestination = AppDestination.ConnectionDetails }
                                        )
                                    }
                                    NavTab.CONFIGS -> {
                                        ConfigsListScreen(
                                            configs = allConfigs,
                                            selectedConfig = selectedConfig,
                                            connectionState = connectionState,
                                            onSelectConfig = { config ->
                                                viewModel.selectConfig(config.id)
                                                currentTab = NavTab.HOME
                                            },
                                            onAddConfig = {
                                                currentDestination = AppDestination.AddEdit(null)
                                            },
                                            onEditConfig = { config ->
                                                if (config.locked) {
                                                    android.widget.Toast.makeText(
                                                        this@MainActivity,
                                                        "This config is locked and cannot be viewed or edited",
                                                        android.widget.Toast.LENGTH_SHORT
                                                    ).show()
                                                } else {
                                                    currentDestination = AppDestination.AddEdit(config)
                                                }
                                            },
                                            onDeleteConfig = { config ->
                                                viewModel.deleteConfig(config)
                                            },
                                            onExportConfigs = { list, options, uri, done ->
                                                viewModel.exportConfigs(list, options, uri, done)
                                            },
                                            onReadBackupFile = { uri, done ->
                                                viewModel.readBackupFile(uri, done)
                                            },
                                            onImportConfigs = { data, password, done ->
                                                viewModel.importConfigs(data, password, done)
                                            }
                                        )
                                    }
                                    NavTab.LOGS -> {
                                        LogsScreen(
                                            logs = logs,
                                            onClearLogs = { viewModel.clearLogs() }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                if (showSplash) AnimatedSplash(onFinished = { showSplash = false })
                }
            }
        }
    }
}
