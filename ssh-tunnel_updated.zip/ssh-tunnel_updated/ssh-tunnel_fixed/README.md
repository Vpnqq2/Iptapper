# SSH Tunnel - Lightweight Android VPN Client

A lightweight, dedicated Android VPN client built with Kotlin, Jetpack Compose, Material 3, and Coroutines. It tunnels Android device traffic through SSH, optionally via an HTTP Proxy with a custom Payload, using the native **HEV Socks5 Tunnel** (`hev-socks5-tunnel`) as the high-performance TUN → SOCKS5 translation engine.

---

## Data Path Architecture

```
Android Applications
        ↓
     VpnService
        ↓
       TUN
        ↓
   HEV Socks5 Tunnel (TProxyService)
        ↓
   Local SOCKS5 (127.0.0.1:DYNAMIC_PORT)
        ↓
   SSH Tunnel [Optionally via Proxy + Payload]
        ↓
     Internet
```

### With HTTP Proxy + Custom Payload:

```
Android Applications
        ↓
     VpnService
        ↓
       TUN
        ↓
   HEV Socks5 Tunnel (TProxyService)
        ↓
   Local SOCKS5 Server
        ↓
   SSH Transport
        ↓
     Proxy
        ↓
    Payload
        ↓
   SSH Server
        ↓
     Internet
```

---

## HEV Socks5 Tunnel Integration

The app is completely prepared and wired to work natively with `hev-socks5-tunnel.aar`.

### 1. Library Dependency
In `app/build.gradle.kts`:
```kotlin
implementation(files("libs/hev-socks5-tunnel.aar"))
```
The `app/libs/` directory is created and ready to receive `hev-socks5-tunnel.aar`.

### 2. Native HEV API (`hev.htproxy.TProxyService`)
The driver `HevTunDriver` connects directly to the official HEV API:
- `TProxyService.TProxyStartService(configPath, tunFd)`: Starts the native routing service.
- `TProxyService.TProxyStopService()`: Gracefully terminates the native service.
- `TProxyService.TProxyIsRunning()`: Verifies that the native engine is actively processing packets.
- `TProxyService.TProxyGetStats()`: Retrieves real-time traffic throughput statistics.

### 3. Dynamic Configuration
Before starting HEV, a configuration file (`hev-tunnel.yaml`) is dynamically generated in `context.filesDir`:
```yaml
tunnel:
  name: tun0
  mtu: 1500
  multi-queue: false
  ipv4: 198.18.0.1
  ipv6: 'fc00::1'

socks5:
  address: 127.0.0.1
  port: <LOCAL_SOCKS5_PORT>
```
The `<LOCAL_SOCKS5_PORT>` is dynamically bound to the exact local port assigned to `LocalSocks5Server`.

### 4. Connection Lifecycle Sequence
1. Initialize `TunnelVpnService`
2. Create Android TUN interface (`vpnBuilder().establish()`)
3. Connect SSH transport (via Proxy/Payload if configured, or direct)
4. Launch internal `LocalSocks5Server` on `127.0.0.1:port`
5. Generate temporary `hev-tunnel.yaml`
6. Invoke `TProxyService.TProxyStartService(configPath, tunFd)`
7. Verify `TProxyService.TProxyIsRunning() == true`
8. **Only then** transition state to `CONNECTED` (if HEV fails to start, the connection is aborted with an error)

### 5. Disconnection Sequence
1. Stop HEV: `TProxyService.TProxyStopService()`
2. Stop `LocalSocks5Server`
3. Disconnect SSH transport
4. Safely close Android TUN `ParcelFileDescriptor`
5. Delete temporary `hev-tunnel.yaml`
6. Transition state to `IDLE`

### 6. VPN Loop Protection
All outbound transport sockets (both HTTP Proxy socket and direct SSH socket) are strictly protected using `VpnService.protect(socket)` prior to establishing network connections, ensuring their traffic never loops back into the TUN interface.

---

## How to Add the AAR and Run

1. Copy your `hev-socks5-tunnel.aar` file into:
   ```
   app/libs/hev-socks5-tunnel.aar
   ```
2. Open the project in Android Studio.
3. Click **Sync Project with Gradle Files**.
4. Build and run:
   ```bash
   gradle assembleDebug
   ```
5. Run unit tests:
   ```bash
   gradle :app:testDebugUnitTest
   ```
