package com.example.core.payload

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PayloadEngineTest {

    @Test
    fun `resolve replaces host and port correctly`() {
        val template = "CONNECT [host]:[port] HTTP/1.1[crlf]Host: [host][crlf]Connection: keep-alive[crlf][crlf]"
        val resolved = PayloadEngine.resolve(template, "192.168.1.100", 2222)

        val expected = "CONNECT 192.168.1.100:2222 HTTP/1.1\r\nHost: 192.168.1.100\r\nConnection: keep-alive\r\n\r\n"
        assertEquals(expected, resolved)
    }

    @Test
    fun `resolve handles host_port variable`() {
        val template = "CONNECT [host_port] [protocol][crlf][crlf]"
        val resolved = PayloadEngine.resolve(template, "ssh.myvpn.net", 443, "HTTP/1.1")

        val expected = "CONNECT ssh.myvpn.net:443 HTTP/1.1\r\n\r\n"
        assertEquals(expected, resolved)
    }

    @Test
    fun `resolve handles cr and lf variants`() {
        val template = "LINE1[cr]LINE2[lf]LINE3[crlf]"
        val resolved = PayloadEngine.resolve(template, "host", 22)

        val expected = "LINE1\rLINE2\nLINE3\r\n"
        assertEquals(expected, resolved)
    }

    @Test
    fun `resolve handles empty template with sensible default`() {
        val resolved = PayloadEngine.resolve("", "example.com", 22)
        assertTrue(resolved.startsWith("CONNECT example.com:22 HTTP/1.1"))
        assertTrue(resolved.endsWith("\r\n\r\n"))
    }

    @Test
    fun `split detection and chunking`() {
        val templateWithSplit = "HEAD / HTTP/1.1[crlf][split]Host: [host][crlf][crlf]"
        assertTrue(PayloadEngine.containsSplit(templateWithSplit))

        val resolved = PayloadEngine.resolve(templateWithSplit, "myhost.com", 80)
        val chunks = PayloadEngine.getChunks(resolved)

        assertEquals(2, chunks.size)
        assertEquals("HEAD / HTTP/1.1\r\n", String(chunks[0], Charsets.ISO_8859_1))
        assertEquals("Host: myhost.com\r\n\r\n", String(chunks[1], Charsets.ISO_8859_1))

        // toBytes removes the [split] token
        val fullBytes = PayloadEngine.toBytes(resolved)
        val fullString = String(fullBytes, Charsets.ISO_8859_1)
        assertFalse(fullString.contains("[split]"))
        assertEquals("HEAD / HTTP/1.1\r\nHost: myhost.com\r\n\r\n", fullString)
    }
}
