package com.example.core.engine

import com.example.data.model.ConnectionState
import com.example.data.model.ConnectionStep
import com.example.data.model.TrafficStats
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TunnelEngineStateMachineTest {

    @Test
    fun `connection steps order and sequence are correct`() {
        val steps = ConnectionStep.values()
        assertEquals(6, steps.size)
        assertEquals(ConnectionStep.CONNECTING_PROXY, steps[0])
        assertEquals(ConnectionStep.SENDING_PAYLOAD, steps[1])
        assertEquals(ConnectionStep.CONNECTING_SSH, steps[2])
        assertEquals(ConnectionStep.AUTHENTICATING, steps[3])
        assertEquals(ConnectionStep.ESTABLISHING_TUNNEL, steps[4])
        assertEquals(ConnectionStep.ROUTING_TRAFFIC, steps[5])

        for (i in 0 until steps.size - 1) {
            assertTrue(steps[i].order < steps[i + 1].order)
        }
    }

    @Test
    fun `connection state properties evaluate accurately`() {
        val idle = ConnectionState.Idle
        assertFalse(idle.isConnected)
        assertFalse(idle.isConnecting)

        val connecting = ConnectionState.Connecting(ConnectionStep.CONNECTING_SSH)
        assertFalse(connecting.isConnected)
        assertTrue(connecting.isConnecting)

        val connected = ConnectionState.Connected()
        assertTrue(connected.isConnected)
        assertFalse(connected.isConnecting)

        val reconnecting = ConnectionState.Reconnecting(attempt = 2, maxAttempts = 5, delaySec = 2)
        assertFalse(reconnecting.isConnected)
        assertTrue(reconnecting.isConnecting)

        val failed = ConnectionState.Failed(reason = "Timeout")
        assertFalse(failed.isConnected)
        assertFalse(failed.isConnecting)
    }

    @Test
    fun `traffic stats formatting behaves as expected`() {
        val statsZero = TrafficStats(0L, 0L, 0L, 0L, 0L)
        assertEquals("0 B", statsZero.formattedDownload())
        assertEquals("0 B", statsZero.formattedUpload())
        assertEquals("00:00:00", statsZero.formattedDuration())

        val statsMb = TrafficStats(
            downloadBytes = 2_516_582L, // ~2.4 MB
            uploadBytes = 1_153_434L,   // ~1.1 MB
            durationSeconds = 754L      // 12m 34s
        )
        assertEquals("2.4 MB", statsMb.formattedDownload())
        assertEquals("1.1 MB", statsMb.formattedUpload())
        assertEquals("3.5 MB", statsMb.formattedTotal())
        assertEquals("00:12:34", statsMb.formattedDuration())
    }
}
