package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tunnel_configs")
data class TunnelConfig(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val sshHost: String,
    val sshPort: Int = 22,
    val sshUsername: String,
    val sshPasswordEncrypted: String = "",
    val sshKeyContent: String = "",
    val sshKeyFileName: String = "",
    val proxyHost: String = "",
    val proxyPort: Int = 8080,
    val proxyUsername: String = "",
    val proxyPasswordEncrypted: String = "",
    val payload: String = "CONNECT [host]:[port] HTTP/1.1[crlf]Host: [host][crlf]Connection: keep-alive[crlf][crlf]",
    val isSelected: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    /** Imported from a locked file: the real details live only in [lockedBlob] and are never shown. */
    val locked: Boolean = false,
    val lockedBlob: String = "",
    /** SSH is carried inside TLS (stunnel-style) with [sniHost] announced as the server name. */
    val tlsEnabled: Boolean = false,
    val sniHost: String = "",
    val tlsVerify: Boolean = false,
    /** ISO 3166-1 alpha-2 code (e.g. "NL") used to show the country flag. */
    val countryCode: String = ""
) {
    fun hasProxy(): Boolean = proxyHost.isNotBlank() && proxyPort > 0

    fun hasPayload(): Boolean = hasProxy() && payload.isNotBlank()

    fun displayHostPort(): String = if (locked) "Locked config" else "$sshHost:$sshPort"

    fun displayProxy(): String = when {
        locked -> if (hasProxy()) "Hidden" else "Direct (No Proxy)"
        hasProxy() -> "$proxyHost:$proxyPort"
        else -> "Direct (No Proxy)"
    }
}
