package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AccentBlueLight,
    onPrimary = Color.White,
    primaryContainer = DeepNavySurfaceVariant,
    onPrimaryContainer = Color.White,
    secondary = AccentCyanGlow,
    onSecondary = Color.Black,
    background = DarkNavyBg,
    onBackground = TextPrimary,
    surface = DeepNavySurface,
    onSurface = TextPrimary,
    surfaceVariant = DeepNavySurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceBorder,
    outlineVariant = SurfaceBorderHighlight,
    error = DisconnectRed,
    onError = Color.White
)

@Composable
fun SshTunnelTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
