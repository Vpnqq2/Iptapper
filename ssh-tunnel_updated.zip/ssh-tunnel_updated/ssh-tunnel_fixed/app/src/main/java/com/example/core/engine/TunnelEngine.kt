package com.example.core.engine

import android.content.Context
import android.os.ParcelFileDescriptor
import com.example.core.logs.LogManager
import com.example.core.payload.PayloadEngine
import com.example.core.proxy.ProxyConnector
import com.example.core.proxy.ProxyException
import com.example.core.ssh.SshClientWrapper
import com.example.core.tun.HevTunDriver
import java.net.InetSocketAddress
import com.example.core.tls.TlsConnector
import com.example.core.proxy.ScanSpace
import com.example.core.proxy.ProxyScanner
import com.example.core.tun.TunDriver
import com.example.data.local.KeystoreHelper
import com.example.data.model.AppSettings
import com.example.data.model.ConnectionState
import com.example.data.model.ConnectionStep
import com.example.data.model.TrafficStats
import com.example.data.model.TunnelConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.atomic.AtomicBoolean

class TunnelEngine(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var job: Job? = null
    private var stopJob: Job? = null
    private val cleanupLock = Any()

    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Idle)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    /** Connecting state whose text never reveals the details of a locked config. */
    private fun safeConnecting(step: ConnectionStep, message: String) =
        ConnectionState.Connecting(step, LogManager.redact(message))

    private val _stats = MutableStateFlow(TrafficStats())
    val stats: StateFlow<TrafficStats> = _stats.asStateFlow()

    private val isStopping = AtomicBoolean(false)

    private var activeConfig: TunnelConfig? = null
    private var activeSettings: AppSettings? = null
    private var currentSocket: Socket? = null
    private var sshClientWrapper: SshClientWrapper? = null
    private var tunDriver: TunDriver? = null
    private var tunPfd: ParcelFileDescriptor? = null

    fun getActiveConfig(): TunnelConfig? = activeConfig

    fun start(
        config: TunnelConfig,
        settings: AppSettings,
        vpnBuilder: () -> ParcelFileDescriptor?,
        socketProtector: (Socket) -> Boolean
    ) {
        if (_state.value.isConnecting || _state.value.isConnected) {
            return
        }

        isStopping.set(false)
        activeConfig = config
        activeSettings = settings

        // Locked configs: keep their details out of logs, states and notifications
        LogManager.setRedaction(
            config.locked,
            if (config.locked) listOf(config.sshHost, config.sshUsername, config.proxyHost, config.proxyUsername, config.sniHost) else emptyList()
        )

        job?.cancel()
        val pendingStop = stopJob
        job = scope.launch {
            // a previous disconnect may still be releasing its resources
            pendingStop?.join()
            runConnectionLoop(config, settings, vpnBuilder, socketProtector)
        }
    }

    private suspend fun runConnectionLoop(
        config: TunnelConfig,
        settings: AppSettings,
        vpnBuilder: () -> ParcelFileDescriptor?,
        socketProtector: (Socket) -> Boolean
    ) {
        var attempt = 0
        val maxAttempts = settings.maxReconnectAttempts

        while (scope.isActive && !isStopping.get()) {
            attempt++
            try {
                connectInternal(config, settings, vpnBuilder, socketProtector)
                attempt = 0

                var lastDownload = 0L
                var lastUpload = 0L
                val connectedSince = System.currentTimeMillis()

                while (scope.isActive && !isStopping.get()) {
                    delay(1000)

                    if (sshClientWrapper?.isConnected() != true) {
                        LogManager.w("SSH connection lost or remote host closed connection")
                        throw IOException("SSH remote closed connection unexpectedly")
                    }

                    if (tunDriver?.isRunning() != true) {
                        LogManager.w("HEV TProxyService stopped unexpectedly")
                        throw IOException("HEV tunnel service terminated unexpectedly")
                    }

                    val currentDriverStats = tunDriver?.stats() ?: TrafficStats()
                    val totalDown = currentDriverStats.downloadBytes.coerceAtLeast(sshClientWrapper?.getDownloadedBytes() ?: 0L)
                    val totalUp = currentDriverStats.uploadBytes.coerceAtLeast(sshClientWrapper?.getUploadedBytes() ?: 0L)

                    val downSpeed = (totalDown - lastDownload).coerceAtLeast(0L)
                    val upSpeed = (totalUp - lastUpload).coerceAtLeast(0L)
                    lastDownload = totalDown
                    lastUpload = totalUp

                    val durationSec = ((System.currentTimeMillis() - connectedSince) / 1000).coerceAtLeast(0L)

                    _stats.value = TrafficStats(
                        downloadBytes = totalDown,
                        uploadBytes = totalUp,
                        downloadSpeedBps = downSpeed,
                        uploadSpeedBps = upSpeed,
                        durationSeconds = durationSec
                    )
                }

                break

            } catch (ce: CancellationException) {
                LogManager.i("Connection cancelled by user")
                cleanup()
                _state.value = ConnectionState.Idle
                break
            } catch (e: Exception) {
                cleanup()

                if (isStopping.get()) {
                    _state.value = ConnectionState.Idle
                    break
                }

                val failureMessage = when (e) {
                    is UnknownHostException -> "Unknown host: ${e.message}"
                    is SocketTimeoutException -> "Connection timed out"
                    is ProxyException -> e.message ?: "Proxy rejected connection"
                    is net.schmizz.sshj.userauth.UserAuthException -> "SSH authentication failed (check credentials)"
                    else -> e.message ?: "Connection error occurred"
                }

                val isCredentialError = failureMessage.contains("authentication failed", ignoreCase = true)
                // A full scan that found nothing will not succeed on an immediate retry either
                val noProxyInRange = failureMessage.startsWith("No working proxy", ignoreCase = true)
                val canRetry = settings.autoReconnect && !isCredentialError && !noProxyInRange && attempt < maxAttempts

                if (canRetry) {
                    val backoffSec = (1 shl (attempt - 1)).coerceAtMost(30)
                    LogManager.w("Reconnecting in $backoffSec seconds (attempt $attempt of $maxAttempts)...")
                    _state.value = ConnectionState.Reconnecting(attempt, maxAttempts, backoffSec)
                    delay(backoffSec * 1000L)
                } else {
                    LogManager.e("Tunnel failed: $failureMessage")
                    _state.value = ConnectionState.Failed(LogManager.redact(failureMessage))
                    break
                }
            }
        }
    }

    private suspend fun connectInternal(
        config: TunnelConfig,
        settings: AppSettings,
        vpnBuilder: () -> ParcelFileDescriptor?,
        socketProtector: (Socket) -> Boolean
    ) {
        LogManager.i("Starting tunnel: ${config.name}")
        val timeoutMs = settings.connectionTimeoutSec * 1000

        var proxySocket: Socket? = null

        // 1. Proxy connection (if configured)
        if (config.hasProxy()) {
            var proxyHostToUse = config.proxyHost

            val scanSpace = ScanSpace.parse(config.proxyHost)?.takeIf { it.total > 1 }
            if (scanSpace != null) {
                // The proxy field holds a range / CIDR: find the best working proxy inside it
                _state.value = safeConnecting(
                    step = ConnectionStep.CONNECTING_PROXY,
                    message = "Scanning ${scanSpace.total} proxy addresses..."
                )
                // Probes never carry the proxy credentials (they go to unknown hosts)
                val probePayload = PayloadEngine.resolve(config.payload, config.sshHost, config.sshPort)
                proxyHostToUse = ProxyScanner.findBest(
                    context = context,
                    cacheKey = "cfg_${config.id}:${config.proxyHost}:${config.proxyPort}",
                    space = scanSpace,
                    port = config.proxyPort,
                    resolvedPayload = probePayload,
                    socketProtector = socketProtector,
                    persistResult = !config.locked,
                    onProgress = { scanned, total, foundCount ->
                        _state.value = safeConnecting(
                            step = ConnectionStep.CONNECTING_PROXY,
                            message = "Scanning proxies $scanned/$total - $foundCount working"
                        )
                    }
                )
            }

            _state.value = safeConnecting(
                step = ConnectionStep.CONNECTING_PROXY,
                message = "Connecting to proxy $proxyHostToUse:${config.proxyPort}"
            )

            _state.value = safeConnecting(
                step = ConnectionStep.SENDING_PAYLOAD,
                message = "Sending payload..."
            )

            val decryptedProxyPass = KeystoreHelper.decrypt(config.proxyPasswordEncrypted)

            proxySocket = ProxyConnector.connect(
                proxyHost = proxyHostToUse,
                proxyPort = config.proxyPort,
                payloadTemplate = config.payload,
                sshHost = config.sshHost,
                sshPort = config.sshPort,
                proxyUsername = config.proxyUsername,
                proxyPassword = decryptedProxyPass,
                timeoutMs = timeoutMs,
                socketProtector = socketProtector
            )
            this.currentSocket = proxySocket
        }

        // 2. Connecting to SSH
        _state.value = safeConnecting(
            step = ConnectionStep.CONNECTING_SSH,
            message = "Connecting to SSH ${config.sshHost}:${config.sshPort}"
        )

        // 2b. TLS / SNI: carry SSH inside TLS (over the proxy tunnel when one is configured)
        var tunnelSocket: Socket? = proxySocket
        if (config.tlsEnabled) {
            _state.value = safeConnecting(
                step = ConnectionStep.CONNECTING_SSH,
                message = "TLS handshake with SNI ${config.sniHost.ifBlank { config.sshHost }}"
            )
            val base: Socket = proxySocket ?: Socket().also { raw ->
                this.currentSocket = raw // closed by cleanup() if anything below fails
                raw.tcpNoDelay = true
                if (!socketProtector(raw)) LogManager.w("Could not protect TLS socket through VPN service")
                raw.connect(InetSocketAddress(config.sshHost, config.sshPort), timeoutMs)
            }
            val tls = TlsConnector.wrap(
                socket = base,
                sni = config.sniHost,
                serverHost = config.sshHost,
                port = config.sshPort,
                verify = config.tlsVerify,
                timeoutMs = timeoutMs
            )
            LogManager.s("TLS established (${tls.session.protocol})")
            this.currentSocket = tls
            tunnelSocket = tls
        }

        val wrapper = SshClientWrapper(context)
        this.sshClientWrapper = wrapper

        // 3. Authenticating SSH
        _state.value = safeConnecting(
            step = ConnectionStep.AUTHENTICATING,
            message = "Authenticating user '${config.sshUsername}'..."
        )

        val decryptedSshPass = KeystoreHelper.decrypt(config.sshPasswordEncrypted)

        val socksPort = wrapper.connect(
            sshHost = config.sshHost,
            sshPort = config.sshPort,
            username = config.sshUsername,
            password = decryptedSshPass,
            privateKeyContent = config.sshKeyContent,
            preConnectedSocket = tunnelSocket,
            timeoutMs = timeoutMs,
            socketProtector = socketProtector,
            udpgwPort = if (settings.udpgwEnabled) settings.udpgwPort else 0
        )

        // 4. Establishing Tunnel (Local SOCKS5 active)
        _state.value = safeConnecting(
            step = ConnectionStep.ESTABLISHING_TUNNEL,
            message = "Establishing local tunnel on 127.0.0.1:$socksPort"
        )
        delay(150)

        // 5. Routing Traffic (Establish TUN interface & Start HEV)
        _state.value = safeConnecting(
            step = ConnectionStep.ROUTING_TRAFFIC,
            message = "Routing device traffic through HEV Socks5 Tunnel..."
        )

        LogManager.i("Establishing VPN TUN interface...")
        val pfd = vpnBuilder() ?: throw IOException("VPN permission revoked or TUN interface creation failed")
        this.tunPfd = pfd

        val driver = HevTunDriver(
            context = context,
            socksStatsProvider = {
                (sshClientWrapper?.getDownloadedBytes() ?: 0L) to (sshClientWrapper?.getUploadedBytes() ?: 0L)
            }
        )
        this.tunDriver = driver

        val dnsList = if (settings.enableTcpDns) {
            listOf(TunDriver.MAP_DNS_ADDRESS) // resolve names on the SSH server (mapdns)
        } else {
            listOfNotNull(settings.primaryDns, settings.secondaryDns).filter { it.isNotBlank() }
        }

        // Start HEV with dynamic SOCKS5 port
        val hevStarted = driver.start(
            pfd = pfd,
            socksHost = "127.0.0.1",
            socksPort = socksPort,
            mtu = settings.mtu,
            dnsServers = dnsList
        )

        if (!hevStarted || !driver.isRunning()) {
            throw IOException("HEV Socks5 Tunnel failed to initialize or start (TProxyStartService returned false)")
        }

        LogManager.s("Tunnel established")
        LogManager.s("VPN is now active (TUN -> HEV -> SOCKS5 -> SSH)")
        LogManager.s("Routing traffic...")

        _state.value = ConnectionState.Connected(System.currentTimeMillis())
    }

    fun stop(reason: String = "User requested disconnect") {
        isStopping.set(true)
        LogManager.i("Disconnecting: $reason")
        job?.cancel()
        // The UI goes idle at once; the blocking teardown (native HEV stop, SSH close) runs off the main thread.
        _state.value = ConnectionState.Idle
        _stats.value = TrafficStats()
        stopJob = scope.launch {
            try {
                cleanup()
            } catch (e: Exception) {
                LogManager.w("Error during disconnect: ${e.message}")
            }
        }
    }

    private fun cleanup() = synchronized(cleanupLock) {
        // Disconnect order (strictly following requirement 6):
        // 1. Stop HEV
        try {
            tunDriver?.stop()
        } catch (e: Exception) {
            LogManager.w("Error stopping HEV driver: ${e.message}")
        }
        tunDriver = null

        // 2. Stop Local SOCKS5 Server & 3. Close SSH connection
        try {
            sshClientWrapper?.close()
        } catch (e: Exception) {
            LogManager.w("Error closing SSH client: ${e.message}")
        }
        sshClientWrapper = null

        // 4. Close TUN interface safely after HEV has detached
        try {
            tunPfd?.close()
        } catch (e: Exception) {
            LogManager.w("Error closing TUN descriptor: ${e.message}")
        }
        tunPfd = null

        // 5. Close Proxy transport socket
        try {
            currentSocket?.close()
        } catch (_: Exception) {}
        currentSocket = null
    }
}
