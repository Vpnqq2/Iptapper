package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.payload.PayloadEngine
import com.example.data.model.TunnelConfig
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentBlueLight
import com.example.ui.theme.CardBackground
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepNavySurfaceVariant
import com.example.ui.theme.InputFieldBackground
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AddEditConfigScreen(
    initialConfig: TunnelConfig? = null,
    initialDecryptedSshPass: String = "",
    initialDecryptedProxyPass: String = "",
    onSave: (config: TunnelConfig, rawSshPass: String, rawProxyPass: String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current

    var name by remember { mutableStateOf(initialConfig?.name ?: "My Server") }
    var sshHost by remember { mutableStateOf(initialConfig?.sshHost ?: "") }
    var sshPort by remember { mutableStateOf((initialConfig?.sshPort ?: 22).toString()) }
    var sshUsername by remember { mutableStateOf(initialConfig?.sshUsername ?: "") }
    var sshPassword by remember { mutableStateOf(initialDecryptedSshPass) }
    var showSshPassword by remember { mutableStateOf(false) }
    var sshKeyFileName by remember { mutableStateOf(initialConfig?.sshKeyFileName ?: "") }
    var sshKeyContent by remember { mutableStateOf(initialConfig?.sshKeyContent ?: "") }

    var proxyHost by remember { mutableStateOf(initialConfig?.proxyHost ?: "") }
    var proxyPort by remember { mutableStateOf((initialConfig?.proxyPort ?: 8080).toString()) }
    var proxyUsername by remember { mutableStateOf(initialConfig?.proxyUsername ?: "") }
    var proxyPassword by remember { mutableStateOf(initialDecryptedProxyPass) }
    var showProxyPassword by remember { mutableStateOf(false) }

    var tlsEnabled by remember { mutableStateOf(initialConfig?.tlsEnabled ?: false) }
    var sniHost by remember { mutableStateOf(initialConfig?.sniHost ?: "") }
    var tlsVerify by remember { mutableStateOf(initialConfig?.tlsVerify ?: false) }

    var payload by remember {
        mutableStateOf(initialConfig?.payload ?: PayloadEngine.DEFAULT_PAYLOAD)
    }

    var hostError by remember { mutableStateOf(false) }
    var userError by remember { mutableStateOf(false) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val inputStream = context.contentResolver.openInputStream(it)
                val content = inputStream?.bufferedReader().use { r -> r?.readText() } ?: ""
                sshKeyContent = content
                sshKeyFileName = it.lastPathSegment ?: "id_rsa"
            } catch (_: Exception) {}
        }
    }

    fun handleSave() {
        if (sshHost.isBlank()) {
            hostError = true
            return
        }
        if (sshUsername.isBlank()) {
            userError = true
            return
        }

        val config = (initialConfig ?: TunnelConfig(
            name = name,
            sshHost = sshHost,
            sshUsername = sshUsername
        )).copy(
            name = name.ifBlank { "Server" },
            sshHost = sshHost.trim(),
            sshPort = sshPort.toIntOrNull() ?: 22,
            sshUsername = sshUsername.trim(),
            sshKeyFileName = sshKeyFileName,
            sshKeyContent = sshKeyContent,
            proxyHost = proxyHost.trim(),
            proxyPort = proxyPort.toIntOrNull() ?: 8080,
            proxyUsername = proxyUsername.trim(),
            payload = payload,
            tlsEnabled = tlsEnabled,
            sniHost = sniHost.trim(),
            tlsVerify = tlsVerify
        )

        onSave(config, sshPassword, proxyPassword)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .statusBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Text(
                    text = if (initialConfig == null) "Add Config" else "Edit Config",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                IconButton(onClick = { handleSave() }, modifier = Modifier.testTag("save_icon_button")) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Save",
                        tint = AccentBlueLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Config Name Field
            SectionLabel("Config Name")
            CustomInputField(
                value = name,
                onValueChange = { name = it },
                placeholder = "My Server",
                testTag = "config_name_input"
            )

            Spacer(modifier = Modifier.height(20.dp))

            // CONNECTION METHOD
            SectionLabel("Connection Method")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MethodChip(
                    label = "SSH + Proxy/Payload",
                    selected = !tlsEnabled,
                    modifier = Modifier.weight(1f).testTag("method_payload")
                ) { tlsEnabled = false }
                MethodChip(
                    label = "SSH + TLS/SNI",
                    selected = tlsEnabled,
                    modifier = Modifier.weight(1f).testTag("method_tls")
                ) { tlsEnabled = true }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // SECTION 1: SSH SETTINGS
            SectionLabel("SSH Settings")

            Row(modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.weight(2.5f)) {
                    CustomInputField(
                        value = sshHost,
                        onValueChange = {
                            sshHost = it
                            hostError = false
                        },
                        placeholder = "Host (e.g. example.com)",
                        isError = hostError,
                        testTag = "ssh_host_input"
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Box(modifier = Modifier.weight(1f)) {
                    CustomInputField(
                        value = sshPort,
                        onValueChange = { sshPort = it },
                        placeholder = "22",
                        keyboardType = KeyboardType.Number,
                        testTag = "ssh_port_input"
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            CustomInputField(
                value = sshUsername,
                onValueChange = {
                    sshUsername = it
                    userError = false
                },
                placeholder = "Username",
                isError = userError,
                testTag = "ssh_username_input"
            )

            Spacer(modifier = Modifier.height(10.dp))

            CustomInputField(
                value = sshPassword,
                onValueChange = { sshPassword = it },
                placeholder = "Password",
                isPassword = true,
                passwordVisible = showSshPassword,
                onTogglePassword = { showSshPassword = !showSshPassword },
                testTag = "ssh_password_input"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // SSH Key Picker
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(InputFieldBackground)
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                    .clickable { filePickerLauncher.launch("*/*") }
                    .padding(horizontal = 16.dp, vertical = 14.dp)
                    .testTag("ssh_key_picker")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "SSH Key (Optional)",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                        Text(
                            text = if (sshKeyFileName.isNotBlank()) sshKeyFileName else "Choose private key file",
                            color = if (sshKeyFileName.isNotBlank()) AccentBlueLight else TextSecondary,
                            fontSize = 14.sp
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = "File picker",
                        tint = AccentBlueLight,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (tlsEnabled) {
                SectionLabel("TLS / SNI")
                Text(
                    text = "SSH runs inside TLS. The server must accept TLS on the SSH port above " +
                        "(usually 443, e.g. stunnel or nginx stream in front of sshd).",
                    color = TextMuted,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                CustomInputField(
                    value = sniHost,
                    onValueChange = { sniHost = it },
                    placeholder = "SNI host (empty = use the SSH host)",
                    testTag = "sni_host_input"
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Verify server certificate", color = TextPrimary, fontSize = 14.sp)
                        Text(
                            "Leave off when the SNI differs from the server's certificate name. " +
                                "The SSH host key is still checked inside the tunnel.",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = tlsVerify,
                        onCheckedChange = { tlsVerify = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentBlueLight)
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            // SECTION 2: PROXY SETTINGS
            SectionLabel(if (tlsEnabled) "Proxy Settings (optional, used before TLS)" else "Proxy Settings")

            Row(modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.weight(2.5f)) {
                    CustomInputField(
                        value = proxyHost,
                        onValueChange = { proxyHost = it },
                        placeholder = "Proxy host, or range: 34.43.0.0-34.43.255.255 / 34.43.0.0/16",
                        testTag = "proxy_host_input"
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Box(modifier = Modifier.weight(1f)) {
                    CustomInputField(
                        value = proxyPort,
                        onValueChange = { proxyPort = it },
                        placeholder = "8080",
                        keyboardType = KeyboardType.Number,
                        testTag = "proxy_port_input"
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            CustomInputField(
                value = proxyUsername,
                onValueChange = { proxyUsername = it },
                placeholder = "Proxy Username (Optional)",
                testTag = "proxy_username_input"
            )

            Spacer(modifier = Modifier.height(10.dp))

            CustomInputField(
                value = proxyPassword,
                onValueChange = { proxyPassword = it },
                placeholder = "Proxy Password (Optional)",
                isPassword = true,
                passwordVisible = showProxyPassword,
                onTogglePassword = { showProxyPassword = !showProxyPassword },
                testTag = "proxy_password_input"
            )

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION 3: PAYLOAD
            SectionLabel("Payload")

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(InputFieldBackground)
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                OutlinedTextField(
                    value = payload,
                    onValueChange = { payload = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .testTag("payload_editor"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    ),
                    placeholder = {
                        Text(
                            text = "CONNECT [host]:[port] HTTP/1.1[crlf]Host: [host][crlf]Connection: keep-alive[crlf][crlf]",
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Save Config Button
            Button(
                onClick = { handleSave() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_config_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentBlue
                )
            ) {
                Text(
                    text = "Save Config",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun SectionLabel(title: String) {
    Text(
        text = title,
        color = TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun CustomInputField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    isPassword: Boolean = false,
    passwordVisible: Boolean = false,
    onTogglePassword: () -> Unit = {},
    isError: Boolean = false,
    testTag: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        visualTransformation = if (isPassword && !passwordVisible) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = {
            if (isPassword) {
                IconButton(onClick = onTogglePassword) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = "Toggle password visibility",
                        tint = TextMuted
                    )
                }
            }
        },
        placeholder = {
            Text(text = placeholder, color = TextMuted, fontSize = 14.sp)
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = InputFieldBackground,
            unfocusedContainerColor = InputFieldBackground,
            focusedBorderColor = AccentBlueLight,
            unfocusedBorderColor = if (isError) Color(0xFFEF4444) else SurfaceBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            cursorColor = AccentBlueLight
        )
    )
}

@Composable
private fun MethodChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) AccentBlueLight.copy(alpha = 0.18f) else InputFieldBackground)
            .border(1.dp, if (selected) AccentBlueLight else SurfaceBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) AccentBlueLight else TextSecondary,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
