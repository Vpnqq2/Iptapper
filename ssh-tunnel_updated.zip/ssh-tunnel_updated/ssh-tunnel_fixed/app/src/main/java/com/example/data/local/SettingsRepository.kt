package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AppSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ssh_tunnel_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        return AppSettings(
            primaryDns = prefs.getString("primaryDns", "1.1.1.1") ?: "1.1.1.1",
            secondaryDns = prefs.getString("secondaryDns", "8.8.8.8") ?: "8.8.8.8",
            mtu = prefs.getInt("mtu", 1500),
            connectionTimeoutSec = prefs.getInt("connectionTimeoutSec", 15),
            autoReconnect = prefs.getBoolean("autoReconnect", true),
            maxReconnectAttempts = prefs.getInt("maxReconnectAttempts", 5),
            enableTcpDns = prefs.getBoolean("enableTcpDns", true),
            blockIpv6 = prefs.getBoolean("blockIpv6", true),
            wakeLockEnabled = prefs.getBoolean("wakeLockEnabled", true),
            udpgwEnabled = prefs.getBoolean("udpgwEnabled", true),
            udpgwPort = prefs.getInt("udpgwPort", 7300)
        )
    }

    fun updateSettings(newSettings: AppSettings) {
        prefs.edit()
            .putString("primaryDns", newSettings.primaryDns)
            .putString("secondaryDns", newSettings.secondaryDns)
            .putInt("mtu", newSettings.mtu)
            .putInt("connectionTimeoutSec", newSettings.connectionTimeoutSec)
            .putBoolean("autoReconnect", newSettings.autoReconnect)
            .putInt("maxReconnectAttempts", newSettings.maxReconnectAttempts)
            .putBoolean("enableTcpDns", newSettings.enableTcpDns)
            .putBoolean("blockIpv6", newSettings.blockIpv6)
            .putBoolean("wakeLockEnabled", newSettings.wakeLockEnabled)
            .putBoolean("udpgwEnabled", newSettings.udpgwEnabled)
            .putInt("udpgwPort", newSettings.udpgwPort)
            .apply()
        _settings.value = newSettings
    }
}
