package com.example.core.vpn

import com.example.core.tun.TunDriver
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.net.wifi.WifiManager
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.MainActivity
import com.example.R
import com.example.SshTunnelApp
import com.example.core.engine.TunnelEngine
import com.example.core.logs.LogManager
import com.example.data.model.ConnectionState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.net.Socket

class TunnelVpnService : VpnService() {

    private lateinit var engine: TunnelEngine
    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private var stateObserverJob: Job? = null
    private var statsObserverJob: Job? = null

    @Volatile private var stopping = false
    private val largeIcon: Bitmap? by lazy {
        runCatching {
            Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.app_logo), 128, 128, true)
        }.getOrNull()
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        engine = TunnelController.getEngine(this)
        createNotificationChannel()
        setupNetworkCallback()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val configId = intent.getLongExtra(EXTRA_CONFIG_ID, -1L)
                startVpn(configId)
            }
            ACTION_DISCONNECT -> {
                stopVpn("User requested disconnect from notification/action")
            }
        }
        return START_NOT_STICKY
    }

    private fun startVpn(configId: Long) {
        stopping = false
        val initialNotification = buildNotification("Ip Tapper", "Connecting...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, initialNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(NOTIFICATION_ID, initialNotification)
        }

        serviceScope.launch(Dispatchers.IO) {
            val app = SshTunnelApp.instance
            val rowConfig = if (configId > 0) {
                app.configRepository.getConfigById(configId)
            } else {
                app.configRepository.getSelectedConfigSync()
            }

            if (rowConfig == null) {
                LogManager.e("No tunnel configuration selected to connect")
                stopVpn("Configuration not found")
                return@launch
            }

            // Locked configs are opened only in memory, for the engine; the UI keeps seeing the masked row
            val config = try {
                app.configRepository.unlock(rowConfig)
            } catch (e: Exception) {
                LogManager.e("This locked config cannot be opened on this device")
                stopVpn("Locked config cannot be opened")
                return@launch
            }

            TunnelController.updateActiveConfig(rowConfig)
            val settings = app.settingsRepository.settings.value

            acquireLocks(settings.wakeLockEnabled)

            engine.start(
                config = config,
                settings = settings,
                vpnBuilder = {
                    val dns = if (settings.enableTcpDns) {
                        listOf(TunDriver.MAP_DNS_ADDRESS)
                    } else {
                        listOf(settings.primaryDns, settings.secondaryDns)
                    }
                    establishVpnInterface("Ip Tapper", settings.mtu, dns)
                },
                socketProtector = { socket -> protect(socket) }
            )
        }

        observeEngine()
    }

    private fun observeEngine() {
        stateObserverJob?.cancel()
        stateObserverJob = serviceScope.launch {
            engine.state.collectLatest { state ->
                val configName = "Ip Tapper"
                when (state) {
                    is ConnectionState.Connecting -> {
                        updateNotification(configName, "Connecting...")
                    }
                    is ConnectionState.Connected -> {
                        updateNotification(configName, "Connected")
                    }
                    is ConnectionState.Reconnecting -> {
                        updateNotification(configName, "Reconnecting...")
                    }
                    is ConnectionState.Failed -> {
                        updateNotification(configName, "Connection failed")
                        stopVpn("Connection failed")
                    }
                    is ConnectionState.Idle -> {
                        removeNotification()
                        stopSelf()
                    }
                }
            }
        }

        statsObserverJob?.cancel()
        statsObserverJob = serviceScope.launch {
            engine.stats.collectLatest { stats ->
                if (engine.state.value is ConnectionState.Connected) {
                    // The notification only shows the connection status (no server or traffic details).
                }
            }
        }
    }

    private fun establishVpnInterface(sessionName: String, mtu: Int, dnsServers: List<String>): ParcelFileDescriptor? {
        val builder = Builder()
            .setSession(sessionName)
            .setMtu(mtu)
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            // Capture IPv6 too so it cannot bypass the tunnel (HEV handles it via SOCKS5)
            .addAddress("fd00::2", 128)
            .addRoute("::", 0)

        // Prevent routing loops by excluding this app's own process from the VPN interface
        try {
            builder.addDisallowedApplication(packageName)
        } catch (e: Exception) {
            LogManager.w("Could not exclude self application: ${e.message}")
        }

        // Add DNS servers
        for (dns in dnsServers) {
            if (dns.isNotBlank()) {
                try {
                    builder.addDnsServer(dns)
                } catch (e: Exception) {
                    LogManager.w("Could not add DNS server $dns: ${e.message}")
                }
            }
        }

        return try {
            builder.establish()
        } catch (e: Exception) {
            LogManager.e("Failed to establish VPN interface: ${e.message}")
            null
        }
    }

    private fun setupNetworkCallback() {
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                super.onAvailable(network)
                try {
                    setUnderlyingNetworks(arrayOf(network))
                } catch (_: Exception) {}
            }

            override fun onLost(network: Network) {
                super.onLost(network)
                try {
                    setUnderlyingNetworks(null)
                } catch (_: Exception) {}
            }
        }

        try {
            connectivityManager?.registerNetworkCallback(request, networkCallback!!)
        } catch (_: Exception) {}
    }

    private fun acquireLocks(enableWakeLock: Boolean) {
        if (!enableWakeLock) return
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SshTunnel:VpnWakeLock").apply {
                acquire(12 * 60 * 60 * 1000L) // 12 hours max
            }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "SshTunnel:VpnWifiLock").apply {
                acquire()
            }
        } catch (_: Exception) {}
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}
        wakeLock = null

        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {}
        wifiLock = null
    }

    override fun onRevoke() {
        LogManager.w("VPN permission revoked by system or another VPN started")
        stopVpn("VPN revoked by Android")
        super.onRevoke()
    }

    private fun stopVpn(reason: String) {
        stateObserverJob?.cancel()
        statsObserverJob?.cancel()
        releaseLocks()
        engine.stop(reason)
        TunnelController.updateActiveConfig(null)
        removeNotification()
        stopSelf()
    }

    /** Takes the notification down for good; later status updates are ignored so it cannot come back. */
    private fun removeNotification() {
        stopping = true
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {}
        try {
            getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        networkCallback?.let {
            try {
                connectivityManager?.unregisterNetworkCallback(it)
            } catch (_: Exception) {}
        }
        releaseLocks()
        removeNotification()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ip Tapper",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live connection status and tunnel statistics"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, content: String): Notification {
        val mainIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val mainPendingIntent = PendingIntent.getActivity(
            this,
            0,
            mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val disconnectIntent = Intent(this, TunnelVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPendingIntent = PendingIntent.getService(
            this,
            1,
            disconnectIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setLargeIcon(largeIcon)
            .setColor(ContextCompat.getColor(this, R.color.notification_accent))
            .setContentTitle(title)
            .setContentText(content)
            .setContentIntent(mainPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Disconnect", disconnectPendingIntent)
            .build()
    }

    private fun updateNotification(title: String, content: String) {
        if (stopping) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(title, content))
    }

    companion object {
        const val ACTION_CONNECT = "com.example.sshtunnel.CONNECT"
        const val ACTION_DISCONNECT = "com.example.sshtunnel.DISCONNECT"
        const val EXTRA_CONFIG_ID = "extra_config_id"
        private const val CHANNEL_ID = "ssh_tunnel_vpn_channel"
        private const val NOTIFICATION_ID = 2001
    }
}
