package com.example.data.model

import java.util.Locale

data class TrafficStats(
    val downloadBytes: Long = 0L,
    val uploadBytes: Long = 0L,
    val downloadSpeedBps: Long = 0L,
    val uploadSpeedBps: Long = 0L,
    val durationSeconds: Long = 0L
) {
    val totalBytes: Long get() = downloadBytes + uploadBytes

    fun formattedDownload(): String = formatBytes(downloadBytes)
    fun formattedUpload(): String = formatBytes(uploadBytes)
    fun formattedTotal(): String = formatBytes(totalBytes)

    fun formattedDuration(): String {
        val hours = durationSeconds / 3600
        val minutes = (durationSeconds % 3600) / 60
        val seconds = durationSeconds % 60
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            var b = bytes.toDouble()
            var unitIndex = 0
            while (b >= 1024.0 && unitIndex < units.size - 1) {
                b /= 1024.0
                unitIndex++
            }
            return if (unitIndex == 0) {
                "${b.toLong()} B"
            } else {
                String.format(Locale.US, "%.1f %s", b, units[unitIndex])
            }
        }
    }
}
