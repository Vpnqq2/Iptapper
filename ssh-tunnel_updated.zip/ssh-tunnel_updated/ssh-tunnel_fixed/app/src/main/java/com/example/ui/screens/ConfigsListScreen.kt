package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.net.Uri
import com.example.data.backup.ExportOptions
import com.example.data.model.ConnectionState
import com.example.data.model.TunnelConfig
import com.example.ui.theme.AccentBlueLight
import com.example.ui.theme.CardBackground
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepNavySurfaceVariant
import com.example.ui.theme.DisconnectRed
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ConfigsListScreen(
    configs: List<TunnelConfig>,
    selectedConfig: TunnelConfig?,
    connectionState: ConnectionState,
    onSelectConfig: (TunnelConfig) -> Unit,
    onAddConfig: () -> Unit,
    onEditConfig: (TunnelConfig) -> Unit,
    onDeleteConfig: (TunnelConfig) -> Unit,
    onExportConfigs: (List<TunnelConfig>, ExportOptions, Uri, (Result<Int>) -> Unit) -> Unit,
    onReadBackupFile: (Uri, (ByteArray?) -> Unit) -> Unit,
    onImportConfigs: (ByteArray, String?, (Result<Int>) -> Unit) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .statusBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Configs",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    ConfigBackupControls(
                        configs = configs,
                        selectedConfig = selectedConfig,
                        onExport = onExportConfigs,
                        onReadFile = onReadBackupFile,
                        onImport = onImportConfigs
                    )
                    IconButton(
                        onClick = onAddConfig,
                        modifier = Modifier.testTag("add_config_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Config",
                            tint = AccentBlueLight,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            if (configs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 60.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "No configurations found",
                            color = TextMuted,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Tap + to add an SSH tunnel configuration",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(configs, key = { it.id }) { config ->
                        val isSelected = config.id == selectedConfig?.id
                        val isConnected = isSelected && connectionState.isConnected

                        ConfigItemCard(
                            config = config,
                            isSelected = isSelected,
                            isConnected = isConnected,
                            onCardClick = { onSelectConfig(config) },
                            onEditClick = { onEditConfig(config) },
                            onDeleteClick = { onDeleteConfig(config) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ConfigItemCard(
    config: TunnelConfig,
    isSelected: Boolean,
    isConnected: Boolean,
    onCardClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBackground)
            .border(
                1.dp,
                if (isSelected) AccentBlueLight.copy(alpha = 0.5f) else SurfaceBorder,
                RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onCardClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag("config_card_${config.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Status dot (Green if connected, Cyan if selected, Muted slate otherwise)
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isConnected -> ConnectedGreen
                                isSelected -> AccentBlueLight
                                else -> Color(0xFF475569)
                            }
                        )
                )

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = config.name,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = config.displayHostPort(),
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Options",
                        tint = TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(DeepNavySurfaceVariant)
                ) {
                    DropdownMenuItem(
                        text = { Text("Edit", color = TextPrimary) },
                        leadingIcon = {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = AccentBlueLight)
                        },
                        onClick = {
                            menuExpanded = false
                            onEditClick()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = DisconnectRed) },
                        leadingIcon = {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = DisconnectRed)
                        },
                        onClick = {
                            menuExpanded = false
                            onDeleteClick()
                        }
                    )
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Select",
                    tint = TextMuted,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
