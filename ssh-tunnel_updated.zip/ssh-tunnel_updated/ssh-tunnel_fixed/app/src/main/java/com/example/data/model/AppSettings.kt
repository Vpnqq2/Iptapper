package com.example.data.model

data class AppSettings(
    val primaryDns: String = "1.1.1.1",
    val secondaryDns: String = "8.8.8.8",
    val mtu: Int = 1500,
    val connectionTimeoutSec: Int = 15,
    val autoReconnect: Boolean = true,
    val maxReconnectAttempts: Int = 5,
    val enableTcpDns: Boolean = true,
    val blockIpv6: Boolean = true,
    val wakeLockEnabled: Boolean = true,
    val udpgwEnabled: Boolean = true,
    val udpgwPort: Int = 7300
)
