package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.backup.ConfigBackup
import com.example.data.backup.ExportMode
import com.example.data.backup.ExportOptions
import com.example.data.model.TunnelConfig
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentBlueLight
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.DisconnectRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

/** Import / Export buttons for the Configs screen, with their file pickers and dialogs. */
@Composable
fun ConfigBackupControls(
    configs: List<TunnelConfig>,
    selectedConfig: TunnelConfig?,
    onExport: (List<TunnelConfig>, ExportOptions, Uri, (Result<Int>) -> Unit) -> Unit,
    onReadFile: (Uri, (ByteArray?) -> Unit) -> Unit,
    onImport: (ByteArray, String?, (Result<Int>) -> Unit) -> Unit
) {
    val context = LocalContext.current
    var showExportDialog by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf<Pair<List<TunnelConfig>, ExportOptions>?>(null) }
    var pendingImport by remember { mutableStateOf<ByteArray?>(null) }
    var importError by remember { mutableStateOf<String?>(null) }

    fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    fun runImport(bytes: ByteArray, password: String?) {
        onImport(bytes, password) { result ->
            result
                .onSuccess { count ->
                    pendingImport = null
                    importError = null
                    toast("Imported $count config(s)")
                }
                .onFailure { e ->
                    val message = e.message ?: "Import failed"
                    if (pendingImport != null) importError = message else toast(message)
                }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val pending = pendingExport
        pendingExport = null
        if (uri != null && pending != null) {
            onExport(pending.first, pending.second, uri) { result ->
                result
                    .onSuccess { count -> toast("Exported $count config(s)") }
                    .onFailure { e -> toast("Export failed: ${e.message}") }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onReadFile(uri) { bytes ->
                when {
                    bytes == null -> toast("Cannot read this file")
                    ConfigBackup.needsPassword(bytes) -> {
                        importError = null
                        pendingImport = bytes
                    }
                    else -> runImport(bytes, null)
                }
            }
        }
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) {
            Icon(
                imageVector = Icons.Default.FileDownload,
                contentDescription = "Import configs",
                tint = AccentBlueLight,
                modifier = Modifier.size(24.dp)
            )
        }
        IconButton(
            onClick = {
                when {
                    configs.isEmpty() -> toast("No configs to export")
                    configs.all { it.locked } -> toast("Locked configs cannot be exported")
                    else -> showExportDialog = true
                }
            }
        ) {
            Icon(
                imageVector = Icons.Default.FileUpload,
                contentDescription = "Export configs",
                tint = AccentBlueLight,
                modifier = Modifier.size(24.dp)
            )
        }
    }

    if (showExportDialog) {
        ExportDialog(
            canExportSelectedOnly = selectedConfig != null && !selectedConfig.locked,
            onDismiss = { showExportDialog = false },
            onConfirm = { selectedOnly, options ->
                showExportDialog = false
                val list = if (selectedOnly && selectedConfig != null) {
                    listOf(selectedConfig)
                } else {
                    configs.filter { !it.locked }
                }
                pendingExport = list to options
                exportLauncher.launch(
                    when (options.mode) {
                        ExportMode.PASSWORD -> "ssh-tunnel-configs.sshcfg"
                        ExportMode.LOCKED -> "ssh-tunnel-locked.sshlock"
                        ExportMode.PLAIN -> "ssh-tunnel-configs.json"
                    }
                )
            }
        )
    }

    val encryptedData = pendingImport
    if (encryptedData != null) {
        ImportPasswordDialog(
            error = importError,
            onDismiss = {
                pendingImport = null
                importError = null
            },
            onConfirm = { password ->
                importError = null
                runImport(encryptedData, password)
            }
        )
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary
)

@Composable
private fun ExportDialog(
    canExportSelectedOnly: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (selectedOnly: Boolean, options: ExportOptions) -> Unit
) {
    var mode by remember { mutableStateOf(ExportMode.PASSWORD) }
    var selectedOnly by remember { mutableStateOf(false) }
    var lockNeedsPassword by remember { mutableStateOf(true) }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    val minLen = ConfigBackup.MIN_PASSWORD_LENGTH
    val usesPassword = mode == ExportMode.PASSWORD || (mode == ExportMode.LOCKED && lockNeedsPassword)
    val passwordOk = password.length >= minLen && password == confirm
    val canExport = !usesPassword || passwordOk

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepNavySurface,
        title = { Text("Export configs", color = TextPrimary) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (canExportSelectedOnly) {
                    SwitchRow("Selected config only", selectedOnly) { selectedOnly = it }
                }

                ModeRow(
                    title = "Password protected",
                    description = "Whoever has the password can import and see everything.",
                    selected = mode == ExportMode.PASSWORD
                ) { mode = ExportMode.PASSWORD }
                ModeRow(
                    title = "Locked",
                    description = "The importer can connect but can never see or export the host, " +
                        "user, password, proxy or payload.",
                    selected = mode == ExportMode.LOCKED
                ) { mode = ExportMode.LOCKED }
                ModeRow(
                    title = "Plain (no encryption)",
                    description = "Readable file. Not recommended.",
                    selected = mode == ExportMode.PLAIN
                ) { mode = ExportMode.PLAIN }

                if (mode == ExportMode.LOCKED) {
                    SwitchRow("Also require a password to import", lockNeedsPassword) { lockNeedsPassword = it }
                    if (!lockNeedsPassword) {
                        Text(
                            "Without a password the file is sealed only with a key built into the app. " +
                                "That stops normal users, but someone who reverse-engineers the app could open it. " +
                                "Use a password for strong protection.",
                            color = DisconnectRed,
                            fontSize = 11.sp
                        )
                    }
                }

                if (usesPassword) {
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password", color = TextMuted) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        colors = fieldColors()
                    )
                    OutlinedTextField(
                        value = confirm,
                        onValueChange = { confirm = it },
                        label = { Text("Confirm password", color = TextMuted) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        colors = fieldColors()
                    )
                    val (hint, hintColor) = when {
                        password.length < minLen -> "At least $minLen characters" to DisconnectRed
                        confirm.isNotEmpty() && password != confirm -> "Passwords do not match" to DisconnectRed
                        password.length < 12 -> "OK - 12+ characters (a passphrase) is much safer" to TextMuted
                        else -> "Strong password" to ConnectedGreen
                    }
                    Text(hint, color = hintColor, fontSize = 12.sp)
                    Text(
                        "AES-256-GCM, key derived with Argon2id. The password cannot be recovered if lost.",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }

                if (mode == ExportMode.PLAIN) {
                    Text(
                        "Warning: the file will contain your passwords in plain text. Anyone who gets it can read them.",
                        color = DisconnectRed,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = canExport,
                onClick = { onConfirm(selectedOnly, ExportOptions(mode, if (usesPassword) password else null)) },
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) { Text("Export") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextMuted) }
        }
    )
}

@Composable
private fun ModeRow(title: String, description: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 13.sp)
            Text(description, color = TextMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ImportPasswordDialog(
    error: String?,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var password by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepNavySurface,
        title = { Text("Encrypted file", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Enter the password used when this file was exported.", color = TextMuted, fontSize = 13.sp)
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password", color = TextMuted) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = fieldColors()
                )
                if (error != null) {
                    Text(error, color = DisconnectRed, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                enabled = password.isNotEmpty(),
                onClick = { onConfirm(password) },
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) { Text("Import") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextMuted) }
        }
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextPrimary, fontSize = 13.sp)
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = AccentBlueLight)
        )
    }
}
