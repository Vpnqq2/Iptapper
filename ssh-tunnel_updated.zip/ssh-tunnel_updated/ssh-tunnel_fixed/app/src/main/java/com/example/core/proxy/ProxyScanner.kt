package com.example.core.proxy

import android.content.Context
import com.example.core.logs.LogManager
import com.example.core.payload.PayloadEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

/**
 * A set of IPv4 addresses described by the user, e.g.
 *   34.43.0.0-34.43.255.255      (range)
 *   34.43.0.0/16                 (CIDR)
 *   1.2.3.4, 5.6.7.0/24          (several, separated by comma / space / new line)
 */
class ScanSpace private constructor(
    private val starts: LongArray,
    private val sizes: LongArray
) {
    val total: Long = sizes.sum()

    fun ipAt(index: Long): String {
        var i = index
        for (k in starts.indices) {
            if (i < sizes[k]) return longToIp(starts[k] + i)
            i -= sizes[k]
        }
        throw IndexOutOfBoundsException("index $index")
    }

    companion object {
        /** Largest space accepted (a /8). */
        const val MAX_TOTAL = 1L shl 24

        /** True when [spec] describes more than one address (so a scan is needed). */
        fun isRange(spec: String): Boolean = (parse(spec)?.total ?: 0L) > 1L

        fun parse(spec: String): ScanSpace? {
            val normalised = spec.trim().replace(Regex("\\s*-\\s*"), "-")
            if (normalised.isEmpty()) return null
            val tokens = normalised.split(Regex("[,;\\s]+")).filter { it.isNotEmpty() }
            if (tokens.isEmpty()) return null

            val starts = ArrayList<Long>()
            val sizes = ArrayList<Long>()
            for (token in tokens) {
                when {
                    token.contains('/') -> {
                        val parts = token.split('/')
                        if (parts.size != 2) return null
                        val ip = ipToLong(parts[0]) ?: return null
                        val prefix = parts[1].toIntOrNull() ?: return null
                        if (prefix !in 8..32) return null
                        val size = 1L shl (32 - prefix)
                        starts.add(ip and (size - 1).inv() and 0xFFFFFFFFL)
                        sizes.add(size)
                    }
                    token.contains('-') -> {
                        val parts = token.split('-')
                        if (parts.size != 2) return null
                        val a = ipToLong(parts[0]) ?: return null
                        val b = ipToLong(parts[1]) ?: return null
                        if (b < a) return null
                        starts.add(a)
                        sizes.add(b - a + 1)
                    }
                    else -> {
                        val ip = ipToLong(token) ?: return null
                        starts.add(ip)
                        sizes.add(1)
                    }
                }
            }
            val space = ScanSpace(starts.toLongArray(), sizes.toLongArray())
            return if (space.total in 1..MAX_TOTAL) space else null
        }

        private fun ipToLong(text: String): Long? {
            val parts = text.split('.')
            if (parts.size != 4) return null
            var result = 0L
            for (p in parts) {
                if (p.isEmpty() || p.length > 3 || !p.all { it.isDigit() }) return null
                val n = p.toInt()
                if (n > 255) return null
                result = (result shl 8) or n.toLong()
            }
            return result
        }

        private fun longToIp(v: Long): String =
            "${(v shr 24) and 255}.${(v shr 16) and 255}.${(v shr 8) and 255}.${v and 255}"
    }
}

/**
 * Finds a working HTTP proxy inside a range of addresses: every candidate gets the user's payload on
 * the given port and must answer 200 (or 101); candidates that then also relay the SSH server's banner
 * are "verified" and preferred. Among the best group the fastest one wins.
 *
 * Addresses are probed in random order (every address exactly once), with bounded parallelism, and the
 * scan stops as soon as enough verified proxies are found, the time budget is spent, or the range is
 * exhausted. The user's proxy credentials are never sent to scanned addresses.
 */
object ProxyScanner {

    private const val WORKERS = 96
    private const val CONNECT_TIMEOUT_MS = 1500
    private const val READ_TIMEOUT_MS = 2500
    private const val BANNER_TIMEOUT_MS = 2000
    private const val TARGET_VERIFIED = 3
    private const val TARGET_ANY = 8
    private const val MAX_DURATION_MS = 120_000L
    private const val PREFS = "proxy_scan_cache"

    private class Candidate(val host: String, val latencyMs: Long, val verified: Boolean)

    suspend fun findBest(
        context: Context,
        cacheKey: String,
        space: ScanSpace,
        port: Int,
        resolvedPayload: String,
        socketProtector: (Socket) -> Boolean,
        persistResult: Boolean = true,
        onProgress: (scanned: Long, total: Long, found: Int) -> Unit
    ): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val sockets = ConcurrentHashMap.newKeySet<Socket>()

        // 1) The proxy that worked last time is tried first: instant reconnects.
        val cached = if (persistResult) prefs.getString(cacheKey, null) else null
        if (cached != null) {
            val hit = withContext(Dispatchers.IO) {
                probe(cached, port, resolvedPayload, socketProtector, sockets)
            }
            sockets.clear()
            if (hit != null) {
                LogManager.s("Reusing last working proxy $cached (${hit.latencyMs} ms)")
                return cached
            }
            LogManager.w("Last working proxy $cached no longer answers, scanning the range...")
        }

        // 2) Scan.
        val permutation = Permutation(space.total)
        val next = AtomicLong(0)
        val scanned = AtomicLong(0)
        val found = CopyOnWriteArrayList<Candidate>()
        val verifiedCount = AtomicInteger(0)
        val stop = AtomicBoolean(false)
        val deadline = System.currentTimeMillis() + MAX_DURATION_MS

        fun closeAll() {
            for (s in sockets.toList()) {
                try { s.close() } catch (_: Exception) {}
            }
        }

        LogManager.i("Scanning ${space.total} addresses on port $port for a working proxy...")
        val pool = Executors.newFixedThreadPool(WORKERS)
        val dispatcher = pool.asCoroutineDispatcher()
        try {
            coroutineScope {
                val progress = launch {
                    while (isActive) {
                        onProgress(scanned.get(), space.total, found.size)
                        delay(400)
                    }
                }
                // When this scope is cancelled (user pressed disconnect) free the blocked workers at once.
                val watcher = launch {
                    try {
                        awaitCancellation()
                    } finally {
                        stop.set(true)
                        closeAll()
                    }
                }
                val workers = List(WORKERS) {
                    launch(dispatcher) {
                        while (!stop.get() && isActive) {
                            val i = next.getAndIncrement()
                            if (i >= space.total) break
                            if (System.currentTimeMillis() > deadline) {
                                if (stop.compareAndSet(false, true)) closeAll()
                                break
                            }
                            val ip = space.ipAt(permutation.map(i))
                            val result = probe(ip, port, resolvedPayload, socketProtector, sockets)
                            scanned.incrementAndGet()
                            if (result != null && !stop.get()) {
                                found.add(result)
                                LogManager.i(
                                    "Proxy answered: $ip (${result.latencyMs} ms" +
                                        (if (result.verified) ", SSH banner OK)" else ")")
                                )
                                val enough = (result.verified && verifiedCount.incrementAndGet() >= TARGET_VERIFIED) ||
                                    found.size >= TARGET_ANY
                                if (enough && stop.compareAndSet(false, true)) closeAll()
                            }
                        }
                    }
                }
                workers.joinAll()
                progress.cancel()
                watcher.cancel()
            }
        } catch (e: CancellationException) {
            throw e
        } finally {
            closeAll()
            pool.shutdownNow()
        }

        onProgress(scanned.get(), space.total, found.size)
        val best = found.filter { it.verified }.minByOrNull { it.latencyMs }
            ?: found.minByOrNull { it.latencyMs }
            ?: throw ProxyException("No working proxy found (${scanned.get()} addresses checked)")

        LogManager.s(
            "Best proxy: ${best.host} (${best.latencyMs} ms${if (best.verified) ", verified" else ""}) " +
                "after ${scanned.get()} probes"
        )
        if (persistResult) prefs.edit().putString(cacheKey, best.host).apply()
        return best.host
    }

    /** One probe: connect, send the payload, expect 200/101, then look for the SSH banner. */
    private fun probe(
        host: String,
        port: Int,
        resolvedPayload: String,
        protector: (Socket) -> Boolean,
        sockets: MutableSet<Socket>
    ): Candidate? {
        val socket = Socket()
        sockets.add(socket)
        try {
            socket.tcpNoDelay = true
            protector(socket)
            val started = System.nanoTime()
            socket.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
            socket.soTimeout = READ_TIMEOUT_MS
            ProxyConnector.writePayload(socket.getOutputStream(), resolvedPayload)

            val input = socket.getInputStream()
            val status = readLineBounded(input) ?: return null
            if (!status.startsWith("HTTP/", ignoreCase = true)) return null
            val code = status.split(" ").getOrNull(1)?.toIntOrNull() ?: return null
            if (code !in 200..299 && code != 101) return null

            var headerLines = 0
            while (true) {
                val line = readLineBounded(input) ?: return null
                if (line.isEmpty()) break
                if (++headerLines > 64) return null
            }
            val latency = (System.nanoTime() - started) / 1_000_000

            socket.soTimeout = BANNER_TIMEOUT_MS
            val banner = try {
                readLineBounded(input)
            } catch (_: SocketTimeoutException) {
                null
            }
            return Candidate(host, latency, banner?.startsWith("SSH-") == true)
        } catch (_: Exception) {
            return null
        } finally {
            sockets.remove(socket)
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun readLineBounded(input: InputStream, max: Int = 1024): String? {
        val sb = StringBuilder()
        while (true) {
            val c = input.read()
            if (c == -1) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) return sb.toString()
            if (c != '\r'.code) {
                if (sb.length >= max) throw IOException("line too long")
                sb.append(c.toChar())
            }
        }
    }

    /** Visits 0 until n exactly once, in a pseudo-random order, without storing anything. */
    private class Permutation(private val n: Long) {
        private val step: Long
        private val offset: Long

        init {
            var s = if (n > 2) n / 3 + Random.nextLong(n / 3 + 1) else 1L
            while (gcd(s, n) != 1L) s++
            step = s
            offset = Random.nextLong(n)
        }

        fun map(i: Long): Long = ((i % n) * (step % n) % n + offset) % n

        private fun gcd(a: Long, b: Long): Long {
            var x = a
            var y = b
            while (y != 0L) {
                val t = x % y
                x = y
                y = t
            }
            return x
        }
    }
}
