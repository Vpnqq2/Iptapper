package com.example.core.ssh

import android.content.Context
import android.content.SharedPreferences
import com.example.core.logs.LogManager
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.common.SecurityUtils
import net.schmizz.sshj.transport.verification.HostKeyVerifier
import java.io.Closeable
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.Socket
import java.net.SocketAddress
import java.security.PublicKey
import javax.net.SocketFactory

class DelegatingSocket(private val delegate: Socket) : Socket() {
    override fun connect(endpoint: SocketAddress?, timeout: Int) {
        // No-op because delegate is already connected (e.g. via proxy)
    }
    override fun isConnected(): Boolean = delegate.isConnected
    override fun isBound(): Boolean = delegate.isBound
    override fun getInputStream(): InputStream = delegate.getInputStream()
    override fun getOutputStream(): OutputStream = delegate.getOutputStream()
    override fun close() = delegate.close()
    override fun isClosed(): Boolean = delegate.isClosed
    override fun setSoTimeout(timeout: Int) { delegate.soTimeout = timeout }
    override fun getSoTimeout(): Int = delegate.soTimeout
    override fun setTcpNoDelay(on: Boolean) { delegate.tcpNoDelay = on }
    override fun getTcpNoDelay(): Boolean = delegate.tcpNoDelay
    override fun setKeepAlive(on: Boolean) { delegate.keepAlive = on }
    override fun getKeepAlive(): Boolean = delegate.keepAlive
    override fun getInetAddress(): InetAddress? = delegate.inetAddress
    override fun getPort(): Int = delegate.port
    override fun getLocalAddress(): InetAddress? = delegate.localAddress
    override fun getLocalPort(): Int = delegate.localPort
}

class SshClientWrapper(private val context: Context) : Closeable {

    private var sshClient: SSHClient? = null
    private var socksServer: LocalSocks5Server? = null
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ssh_host_keys", Context.MODE_PRIVATE)

    fun connect(
        sshHost: String,
        sshPort: Int,
        username: String,
        password: String,
        privateKeyContent: String = "",
        preConnectedSocket: Socket? = null,
        timeoutMs: Int = 15000,
        socketProtector: (Socket) -> Boolean,
        udpgwPort: Int = 0
    ): Int {
        val client = SSHClient()
        this.sshClient = client
        client.timeout = timeoutMs
        client.connectTimeout = timeoutMs

        // Custom SocketFactory to support both pre-connected proxy sockets and protected direct sockets
        client.socketFactory = object : SocketFactory() {
            override fun createSocket(): Socket {
                return if (preConnectedSocket != null) {
                    DelegatingSocket(preConnectedSocket)
                } else {
                    val s = Socket()
                    s.tcpNoDelay = true
                    socketProtector(s)
                    s
                }
            }
            override fun createSocket(host: String?, port: Int): Socket = createSocket()
            override fun createSocket(host: String?, port: Int, localHost: InetAddress?, localPort: Int): Socket = createSocket()
            override fun createSocket(host: InetAddress?, port: Int): Socket = createSocket()
            override fun createSocket(address: InetAddress?, port: Int, localAddress: InetAddress?, localPort: Int): Socket = createSocket()
        }

        client.addHostKeyVerifier(object : HostKeyVerifier {
            override fun verify(hostname: String, port: Int, key: PublicKey): Boolean {
                val fp = SecurityUtils.getFingerprint(key)
                val keyPref = "$hostname:$port"
                val savedFp = prefs.getString(keyPref, null)
                if (savedFp == null) {
                    prefs.edit().putString(keyPref, fp).apply()
                    LogManager.i("Host key fingerprint recorded: $fp")
                    return true
                } else if (savedFp != fp) {
                    LogManager.w("WARNING: Host key changed for $hostname! Expected: $savedFp, Received: $fp")
                    return true
                }
                return true
            }

            override fun findExistingAlgorithms(hostname: String, port: Int): List<String> {
                return emptyList()
            }
        })

        if (preConnectedSocket != null) {
            LogManager.i("Handshaking SSH over proxy socket to $sshHost:$sshPort...")
        } else {
            LogManager.i("Connecting directly to SSH $sshHost:$sshPort...")
        }

        client.connect(sshHost, sshPort)

        LogManager.s("SSH connection established")
        LogManager.i("Authenticating user '$username'...")

        if (privateKeyContent.isNotBlank()) {
            try {
                val keyProvider = client.loadKeys(privateKeyContent, null, null)
                client.authPublickey(username, keyProvider)
                LogManager.s("SSH key authentication successful")
            } catch (e: Exception) {
                LogManager.w("Public key auth failed: ${e.message}, falling back to password")
                client.authPassword(username, password)
                LogManager.s("SSH password authentication successful")
            }
        } else {
            client.authPassword(username, password)
            LogManager.s("SSH authentication successful")
        }

        // Enable keepalive every 30 seconds
        try {
            client.connection.keepAlive.keepAliveInterval = 30
        } catch (_: Exception) {}

        // Launch internal SOCKS5 dynamic forwarder
        LogManager.i("Starting local SOCKS5 dynamic forwarder...")
        val server = LocalSocks5Server(
            sshClientProvider = { this.sshClient },
            udpgwPort = udpgwPort
        )
        val socksPort = server.start()
        this.socksServer = server
        LogManager.s("Tunnel established on 127.0.0.1:$socksPort")

        return socksPort
    }

    fun isConnected(): Boolean {
        return sshClient?.isConnected == true && sshClient?.isAuthenticated == true
    }

    fun getDownloadedBytes(): Long = socksServer?.totalDownloaded?.get() ?: 0L

    fun getUploadedBytes(): Long = socksServer?.totalUploaded?.get() ?: 0L

    fun getSocksPort(): Int = socksServer?.actualPort ?: 0

    override fun close() {
        try {
            socksServer?.close()
        } catch (_: Exception) {}
        try {
            sshClient?.disconnect()
        } catch (_: Exception) {}
        socksServer = null
        sshClient = null
    }
}
