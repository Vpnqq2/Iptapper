package com.example.core.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.example.core.engine.TunnelEngine
import com.example.data.model.AppSettings
import com.example.data.model.ConnectionState
import com.example.data.model.TrafficStats
import com.example.data.model.TunnelConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object TunnelController {

    private var engine: TunnelEngine? = null

    private val _activeConfig = MutableStateFlow<TunnelConfig?>(null)
    val activeConfig: StateFlow<TunnelConfig?> = _activeConfig.asStateFlow()

    fun getEngine(context: Context): TunnelEngine {
        return engine ?: synchronized(this) {
            engine ?: TunnelEngine(context.applicationContext).also { engine = it }
        }
    }

    fun isVpnPrepared(context: Context): Boolean {
        return VpnService.prepare(context) == null
    }

    fun getPrepareIntent(context: Context): Intent? {
        return VpnService.prepare(context)
    }

    fun startTunnel(context: Context, config: TunnelConfig) {
        _activeConfig.value = config
        val intent = Intent(context, TunnelVpnService::class.java).apply {
            action = TunnelVpnService.ACTION_CONNECT
            putExtra(TunnelVpnService.EXTRA_CONFIG_ID, config.id)
        }
        context.startForegroundService(intent)
    }

    fun stopTunnel(context: Context, reason: String = "User disconnected") {
        val intent = Intent(context, TunnelVpnService::class.java).apply {
            action = TunnelVpnService.ACTION_DISCONNECT
        }
        context.startService(intent)
        engine?.stop(reason)
        _activeConfig.value = null
    }

    fun updateActiveConfig(config: TunnelConfig?) {
        _activeConfig.value = config
    }
}
