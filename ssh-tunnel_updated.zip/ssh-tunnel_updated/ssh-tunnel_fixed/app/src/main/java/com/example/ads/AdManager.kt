package com.example.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.BuildConfig
import com.example.core.logs.LogManager
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import kotlin.concurrent.thread

/** Initialises AdMob and keeps one interstitial preloaded, ready to show when a connection succeeds. */
object AdManager {
    private val main = Handler(Looper.getMainLooper())
    private var interstitial: InterstitialAd? = null
    private var loading = false
    private var started = false
    private var lastShownAt = 0L
    private var pendingActivity: java.lang.ref.WeakReference<Activity>? = null
    private var pendingSince = 0L

    /** True once consent allows ads and the SDK was started; the banner waits for this. */
    var adsReady by mutableStateOf(false)
        private set

    /** Minimum gap between two interstitials, so reconnecting a few times in a row is not annoying. */
    private const val MIN_INTERVAL_MS = 60_000L

    fun init(context: Context) {
        if (started) return
        started = true
        adsReady = true
        val app = context.applicationContext
        thread(name = "admob-init") {
            try {
                MobileAds.initialize(app) { main.post { loadInterstitial(app) } }
            } catch (e: Exception) {
                LogManager.w("AdMob init failed: ${e.message}")
            }
        }
    }

    fun loadInterstitial(context: Context) {
        if (loading || interstitial != null) return
        loading = true
        InterstitialAd.load(
            context.applicationContext,
            BuildConfig.ADMOB_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    loading = false
                    // A connection succeeded while the ad was still loading: show it now (within 15 s).
                    val waiting = pendingActivity?.get()
                    pendingActivity = null
                    if (waiting != null && System.currentTimeMillis() - pendingSince < 15_000L) {
                        showInterstitial(waiting)
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    loading = false
                    LogManager.w("Interstitial failed to load: ${error.message}")
                }
            }
        )
    }

    /** Shows the interstitial if one is ready. Always safe to call. */
    fun showInterstitial(activity: Activity) {
        val ad = interstitial
        if (ad == null) {
            LogManager.i("Interstitial not ready yet, will show when loaded")
            pendingActivity = java.lang.ref.WeakReference(activity)
            pendingSince = System.currentTimeMillis()
            loadInterstitial(activity)
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastShownAt < MIN_INTERVAL_MS) {
            LogManager.i("Interstitial skipped: shown less than 60 s ago")
            return
        }
        LogManager.i("Showing interstitial")
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitial = null
                loadInterstitial(activity)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                interstitial = null
                loadInterstitial(activity)
            }

            override fun onAdShowedFullScreenContent() {
                lastShownAt = System.currentTimeMillis()
            }
        }
        ad.show(activity)
    }
}
