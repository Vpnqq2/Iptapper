package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.AdBanner
import com.example.ads.ConsentManager
import com.example.data.model.ConnectionState
import com.example.data.remote.FlagLoader
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val BgTop = Color(0xFF0B1230)
private val BgBottom = Color(0xFF060B1E)
private val Purple = Color(0xFF8B5CF6)
private val Blue = Color(0xFF3B82F6)
private val Cyan = Color(0xFF22D3EE)
private val Green = Color(0xFF22C55E)
private val Red = Color(0xFFF87171)

private enum class Mode { IDLE, WORKING, RECONNECTING, CONNECTED, FAILED, CLOSING }

/** Country code ("NL") -> flag emoji. Falls back to a globe. */
fun flagEmoji(code: String): String {
    val c = code.trim().uppercase()
    if (c.length != 2 || c.any { it !in 'A'..'Z' }) return "\uD83C\uDF10"
    val base = 0x1F1E6
    val sb = StringBuilder()
    for (ch in c) sb.appendCodePoint(base + (ch - 'A'))
    return sb.toString()
}

@Composable
fun TapHomeScreen(
    appNameLight: String,
    appNameAccent: String,
    connectionState: ConnectionState,
    fetching: Boolean,
    error: String?,
    countryCode: String?,
    ip: String?,
    flagUrl: String?,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onTitleLongPress: () -> Unit
) {
    var showPrivacy by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val currentLongPress by rememberUpdatedState(onTitleLongPress)

    val realMode = when {
        connectionState is ConnectionState.Connected -> Mode.CONNECTED
        connectionState is ConnectionState.Reconnecting -> Mode.RECONNECTING
        fetching || connectionState.isConnecting -> Mode.WORKING
        connectionState is ConnectionState.Failed || error != null -> Mode.FAILED
        else -> Mode.IDLE
    }

    // "Disconnecting" lasts until the VPN service really reports idle/failed (with a safety timeout),
    // so READY is never shown before the connection is actually stopped.
    var disconnecting by remember { mutableStateOf(false) }
    var lastMode by remember { mutableStateOf(realMode) }
    LaunchedEffect(realMode) {
        val previous = lastMode
        lastMode = realMode
        if (realMode != previous &&
            (realMode == Mode.CONNECTED || realMode == Mode.FAILED || realMode == Mode.IDLE)
        ) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
        if (realMode == Mode.IDLE || realMode == Mode.FAILED) disconnecting = false
    }
    LaunchedEffect(disconnecting) {
        if (disconnecting) {
            kotlinx.coroutines.delay(8000)
            disconnecting = false
        }
    }
    val mode = if (disconnecting && (realMode == Mode.CONNECTED || realMode == Mode.WORKING || realMode == Mode.RECONNECTING)) {
        Mode.CLOSING
    } else realMode
    var lastTap by remember { mutableLongStateOf(0L) }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(mode) {
        while (mode == Mode.CONNECTED) {
            now = System.currentTimeMillis()
            kotlinx.coroutines.delay(1000)
        }
    }

    val accent by animateColorAsState(
        when (mode) {
            Mode.CONNECTED -> Green
            Mode.WORKING, Mode.RECONNECTING -> Cyan
            Mode.FAILED -> Red
            Mode.IDLE -> Blue
            Mode.CLOSING -> Purple
        },
        tween(600), label = "accent"
    )
    val glowColor by animateColorAsState(if (mode == Mode.CONNECTED) Green else Purple, tween(900), label = "glow")

    val connectedSeconds = if (connectionState is ConnectionState.Connected) {
        ((now - connectionState.connectedAt) / 1000).coerceAtLeast(0)
    } else 0L

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
    ) {
        // coloured glow on both sides
        Canvas(Modifier.fillMaxSize()) {
            val r = size.width * 0.75f
            val cy = size.height * 0.42f
            drawCircle(Brush.radialGradient(listOf(glowColor.copy(alpha = 0.20f), Color.Transparent), Offset(0f, cy), r), r, Offset(0f, cy))
            drawCircle(Brush.radialGradient(listOf(glowColor.copy(alpha = 0.20f), Color.Transparent), Offset(size.width, cy), r), r, Offset(size.width, cy))
        }

        Waves(color = accent, modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(120.dp))

        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top bar
            Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Row(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .pointerInput(Unit) { detectTapGestures(onLongPress = { currentLongPress() }) }
                ) {
                    Text(appNameLight, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                    Spacer(Modifier.width(6.dp))
                    Text(appNameAccent, color = Purple, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                }
                IconButton(
                    onClick = { showPrivacy = true },
                    modifier = Modifier.align(Alignment.CenterEnd).size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.07f))
                ) {
                    Icon(Icons.Default.Security, contentDescription = "Privacy Policy", tint = Color(0xFFCBD5E1), modifier = Modifier.size(20.dp))
                }
            }

            Spacer(Modifier.height(14.dp))

            StatusPill(mode = mode, accent = accent, seconds = connectedSeconds)

            ErrorSlot(if (mode == Mode.FAILED) (error ?: (connectionState as? ConnectionState.Failed)?.reason) else null)

            // Hexagonal connect button; it scales to whatever space is left on screen
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                ConnectHero(
                    visual = when (mode) {
                        Mode.IDLE -> ConnectVisual.READY
                        Mode.WORKING -> ConnectVisual.CONNECTING
                        Mode.RECONNECTING -> ConnectVisual.RECONNECTING
                        Mode.CONNECTED -> ConnectVisual.CONNECTED
                        Mode.CLOSING -> ConnectVisual.DISCONNECTING
                        Mode.FAILED -> ConnectVisual.ERROR
                    },
                    onClick = {
                        val nowMs = System.currentTimeMillis()
                        // one completed swipe = one request; ignore rapid repeats and swipes while disconnecting
                        if (nowMs - lastTap >= 700 && mode != Mode.CLOSING) {
                            lastTap = nowMs
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            when (mode) {
                                Mode.IDLE, Mode.FAILED -> onConnect()
                                Mode.CONNECTED, Mode.WORKING, Mode.RECONNECTING -> {
                                    disconnecting = true
                                    onDisconnect()
                                }
                                Mode.CLOSING -> Unit
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // IP card: slides/fades in when there is a server to show
            IpSlot(
                visible = ip != null && (mode == Mode.CONNECTED || mode == Mode.WORKING || mode == Mode.RECONNECTING || mode == Mode.CLOSING),
                accent = accent, countryCode = countryCode.orEmpty(), ip = ip.orEmpty(), flagUrl = flagUrl.orEmpty()
            )

            // gap so the IP card sits clearly above the banner
            Spacer(Modifier.height(24.dp))

            // AdMob banner pinned at the bottom
            AdBanner(Modifier.fillMaxWidth().padding(bottom = 6.dp))
        }
    }

    if (showPrivacy) PrivacyDialog(onClose = { showPrivacy = false })
}

@Composable
private fun ErrorSlot(message: String?) {
    // Keeps the last message while fading out so the layout does not jump.
    var shown by remember { mutableStateOf("") }
    if (!message.isNullOrBlank()) shown = message
    Box(Modifier.height(64.dp).padding(horizontal = 28.dp), contentAlignment = Alignment.Center) {
        AnimatedVisibility(visible = !message.isNullOrBlank(), enter = fadeIn(tween(300)), exit = fadeOut(tween(200))) {
            Text(shown, color = Color(0xFF94A3B8), fontSize = 12.sp, lineHeight = 16.sp, textAlign = TextAlign.Center, maxLines = 3)
        }
    }
}

@Composable
private fun IpSlot(visible: Boolean, accent: Color, countryCode: String, ip: String, flagUrl: String) {
    var lastCc by remember { mutableStateOf(countryCode) }
    var lastIp by remember { mutableStateOf(ip) }
    var lastFlag by remember { mutableStateOf(flagUrl) }
    if (visible) { lastCc = countryCode; lastIp = ip; lastFlag = flagUrl }
    Box(Modifier.fillMaxWidth().height(70.dp), contentAlignment = Alignment.Center) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 2 } + scaleIn(tween(450), initialScale = 0.9f),
            exit = fadeOut(tween(250)) + slideOutVertically(tween(250)) { it / 3 } + scaleOut(tween(250), targetScale = 0.95f)
        ) {
            IpCard(accent = accent, countryCode = lastCc, ip = lastIp, flagUrl = lastFlag)
        }
    }
}

@Composable
private fun StatusPill(mode: Mode, accent: Color, seconds: Long) {
    val t = rememberInfiniteTransition(label = "pill")
    val blink by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "blink")
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(accent.copy(alpha = 0.12f))
            .border(1.dp, accent.copy(alpha = 0.40f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(6.dp).clip(CircleShape)
                .background(accent.copy(alpha = if (mode == Mode.WORKING || mode == Mode.RECONNECTING || mode == Mode.CLOSING) blink else 1f))
        )
        Spacer(Modifier.width(8.dp))
        Crossfade(targetState = mode, animationSpec = tween(350), label = "pillText") { m ->
            val text = when (m) {
                Mode.IDLE -> "READY \u00B7 SWIPE TO CONNECT"
                Mode.WORKING -> "SWITCHING IP..."
                Mode.RECONNECTING -> "RECONNECTING..."
                Mode.CONNECTED -> "CONNECTED \u00B7 %02d:%02d:%02d".format(seconds / 3600, (seconds / 60) % 60, seconds % 60)
                Mode.FAILED -> "FAILED \u00B7 SWIPE TO RETRY"
                Mode.CLOSING -> "DISCONNECTING..."
            }
            Text(text, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun IpCard(accent: Color, countryCode: String, ip: String, flagUrl: String) {
    val context = LocalContext.current
    val flag by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, flagUrl) {
        value = if (flagUrl.isBlank()) null else FlagLoader.load(context, flagUrl)?.asImageBitmap()
    }
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.04f))))
            .border(1.dp, accent.copy(alpha = 0.30f), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(width = 36.dp, height = 26.dp).clip(RoundedCornerShape(6.dp)).background(Color.White.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            val bmp = flag
            Crossfade(targetState = bmp, animationSpec = tween(300), label = "flag") { b ->
                if (b != null) {
                    Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else {
                    Text(flagEmoji(countryCode), fontSize = 16.sp)
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("YOUR IP", color = Color(0xFF94A3B8), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text(ip, color = Color.White, fontSize = 15.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun Waves(color: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Restart), label = "phase")
    Canvas(modifier) {
        for (layer in 0 until 3) {
            val path = Path()
            val amp = (7 + layer * 4).dp.toPx()
            val baseY = size.height * (0.40f + layer * 0.20f)
            path.moveTo(0f, size.height)
            path.lineTo(0f, baseY)
            var x = 0f
            while (x <= size.width) {
                val y = baseY + amp * sin(x / size.width * 2f * PI.toFloat() * (1f + layer * 0.3f) + phase * (if (layer % 2 == 0) 1 else -1) + layer)
                path.lineTo(x, y)
                x += 8f
            }
            path.lineTo(size.width, size.height)
            path.close()
            drawPath(path, color.copy(alpha = 0.09f - layer * 0.02f))
        }
    }
}

@Composable
private fun PrivacyDialog(onClose: () -> Unit) {
    val activity = LocalContext.current as? android.app.Activity
    val showAdOptions = activity != null && ConsentManager.privacyOptionsRequired(activity)
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF111A3A),
        icon = { Icon(Icons.Default.Security, null, tint = Blue, modifier = Modifier.size(36.dp)) },
        title = { Text("Privacy Policy", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.height(280.dp).verticalScroll(rememberScrollState())) {
                Text(PRIVACY_TEXT, color = Color(0xFFCBD5E1), fontSize = 14.sp, lineHeight = 20.sp)
            }
        },
        confirmButton = {
            Column(Modifier.fillMaxWidth()) {
                if (showAdOptions) {
                    androidx.compose.material3.TextButton(
                        onClick = { activity?.let { ConsentManager.showPrivacyOptions(it) } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Ad privacy settings", color = Cyan) }
                }
                Button(
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) { Text("Close", color = Color.White) }
            }
        }
    )
}

private const val PRIVACY_TEXT = """Your privacy matters. This policy explains what the app does with your information.

What the app does
The app creates a secure tunnel (VPN-style connection) and sends your device's internet traffic through a remote server. The server is chosen automatically from a list the app downloads when you tap connect.

Information we collect
We do not collect your name, email, phone number, contacts, or location. We do not sell your personal data.

Ads and notifications
The app shows ads served by Google AdMob, which may use your device's advertising ID and similar technical data to select and measure ads. The app also uses Firebase Cloud Messaging to deliver notifications to your device. These Google services process data under Google's own privacy policy.

Your traffic
While connected, your internet traffic passes through the selected server, so the server operator can technically see connection metadata such as the destinations you reach. Traffic to secure (HTTPS) sites stays encrypted end to end. Avoid entering sensitive information on sites that are not encrypted.

Data stored on your device
The app keeps a copy of the downloaded server list on your device in encrypted form so it can work when the list cannot be downloaded. Connection logs stay on your device and are not uploaded anywhere.

Network access
The app needs internet access to download the server list and to establish the tunnel. The VPN permission is used only to route your traffic through the tunnel.

Children
The app is not directed to children under 13.

Changes
This policy may be updated from time to time. Continued use of the app means you accept the updated policy.

Contact
If you have questions about this policy, contact the developer through the app's store page."""
