package com.example.core.tun

import android.os.ParcelFileDescriptor
import com.example.data.model.TrafficStats

interface TunDriver {
    companion object {
        /** Fake DNS server answered inside HEV (mapdns): names are resolved on the SSH server side. */
        const val MAP_DNS_ADDRESS = "198.18.0.2"
    }

    /**
     * Starts routing IP packets from TUN interface into the local SOCKS5 proxy using HEV.
     *
     * @param pfd The ParcelFileDescriptor of the Android VPN TUN interface.
     * @param socksHost Local SOCKS5 server host (e.g. "127.0.0.1").
     * @param socksPort Dynamic Local SOCKS5 server port.
     * @param mtu Maximum Transmission Unit (typically 1500).
     * @param dnsServers List of configured DNS servers for DNS resolution.
     * @return True if HEV service started and is confirmed running, false otherwise.
     */
    fun start(
        pfd: ParcelFileDescriptor,
        socksHost: String,
        socksPort: Int,
        mtu: Int,
        dnsServers: List<String>
    ): Boolean

    /**
     * Gracefully stops the HEV TUN service and releases resources.
     */
    fun stop()

    /**
     * Returns true if the native HEV proxy service is actively running.
     */
    fun isRunning(): Boolean

    /**
     * Queries real-time traffic statistics from HEV native engine and LocalSocks5.
     */
    fun stats(): TrafficStats
}
