package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val SplashBlue = Color(0xFF3B82F6)
private val SplashPurple = Color(0xFF8B5CF6)
private val SplashCyan = Color(0xFF22D3EE)

/**
 * Animated launch screen: the logo pops in with a spring, pulse rings expand around it,
 * a gradient arc orbits it, the name fades in with a loading bar, then everything fades out.
 */
@Composable
fun AnimatedSplash(onFinished: () -> Unit) {
    val finished by rememberUpdatedState(onFinished)

    val logoScale = remember { Animatable(0.55f) }
    val logoAlpha = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }
    var exiting by remember { mutableStateOf(false) }
    val exitAlpha by animateFloatAsState(if (exiting) 0f else 1f, tween(450), label = "exit")
    val exitScale by animateFloatAsState(if (exiting) 1.08f else 1f, tween(450), label = "exitScale")

    val t = rememberInfiniteTransition(label = "splash")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "spin")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "pulse")

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { logoAlpha.animateTo(1f, tween(500)) }
            launch { logoScale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
            launch {
                delay(350)
                textAlpha.animateTo(1f, tween(500))
            }
            launch {
                delay(300)
                progress.animateTo(1f, tween(1500, easing = FastOutSlowInEasing))
            }
        }
        delay(250)
        exiting = true
        delay(450)
        finished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = exitAlpha; scaleX = exitScale; scaleY = exitScale }
            .background(Brush.verticalGradient(listOf(Color(0xFF020617), Color(0xFF0B1230), Color(0xFF020617)))),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val logoR = 85.dp.toPx()
            val maxR = size.minDimension * 0.48f

            // soft glow behind the logo
            drawCircle(
                Brush.radialGradient(listOf(SplashBlue.copy(alpha = 0.30f * logoAlpha.value), Color.Transparent), c, maxR),
                radius = maxR, center = c
            )
            // expanding pulse rings
            for (i in 0 until 3) {
                val p = (pulse + i / 3f) % 1f
                val r = logoR + (maxR - logoR) * p
                drawCircle(SplashCyan.copy(alpha = 0.30f * (1f - p) * logoAlpha.value), radius = r, center = c, style = Stroke(1.5f.dp.toPx()))
            }
            // orbiting gradient arc
            val orbitR = logoR + 14.dp.toPx()
            rotate(spin, c) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Color.Transparent, SplashBlue, SplashPurple, Color.Transparent), c),
                    startAngle = 0f, sweepAngle = 140f, useCenter = false,
                    topLeft = Offset(c.x - orbitR, c.y - orbitR),
                    size = androidx.compose.ui.geometry.Size(orbitR * 2, orbitR * 2),
                    alpha = logoAlpha.value,
                    style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        Image(
            painter = painterResource(R.drawable.app_logo),
            contentDescription = null,
            modifier = Modifier
                .size(150.dp)
                .scale(logoScale.value)
                .graphicsLayer { alpha = logoAlpha.value }
        )

        Column(
            modifier = Modifier.offset(y = 150.dp).graphicsLayer { alpha = textAlpha.value },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            androidx.compose.foundation.layout.Row {
                Text("IP", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                Spacer(Modifier.width(8.dp))
                Text("TAPPER", color = SplashPurple, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            }
            Spacer(Modifier.height(18.dp))
            // thin loading bar
            Box(Modifier.width(140.dp).height(3.dp).background(Color.White.copy(alpha = 0.10f), androidx.compose.foundation.shape.RoundedCornerShape(50))) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                            scaleX = progress.value
                        }
                        .background(
                            Brush.horizontalGradient(listOf(SplashBlue, SplashPurple)),
                            androidx.compose.foundation.shape.RoundedCornerShape(50)
                        )
                )
            }
        }
    }
}
