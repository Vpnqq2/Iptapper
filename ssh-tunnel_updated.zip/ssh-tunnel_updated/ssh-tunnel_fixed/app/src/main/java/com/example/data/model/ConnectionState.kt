package com.example.data.model

enum class ConnectionStep(val displayName: String, val order: Int) {
    CONNECTING_PROXY("Connecting to Proxy", 1),
    SENDING_PAYLOAD("Sending Payload", 2),
    CONNECTING_SSH("Connecting to SSH", 3),
    AUTHENTICATING("Authenticating", 4),
    ESTABLISHING_TUNNEL("Establishing Tunnel", 5),
    ROUTING_TRAFFIC("Routing Traffic", 6)
}

sealed class ConnectionState {
    object Idle : ConnectionState()

    data class Connecting(
        val step: ConnectionStep = ConnectionStep.CONNECTING_SSH,
        val message: String = "Setting up tunnel"
    ) : ConnectionState()

    data class Connected(
        val connectedAt: Long = System.currentTimeMillis()
    ) : ConnectionState()

    data class Reconnecting(
        val attempt: Int,
        val maxAttempts: Int,
        val delaySec: Int
    ) : ConnectionState()

    data class Failed(
        val reason: String,
        val timestamp: Long = System.currentTimeMillis()
    ) : ConnectionState()

    val isConnected: Boolean get() = this is Connected
    val isConnecting: Boolean get() = this is Connecting || this is Reconnecting
}
