package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkNavyBg = Color(0xFF090E1A)
val DeepNavySurface = Color(0xFF101728)
val DeepNavySurfaceVariant = Color(0xFF162035)
val SurfaceBorder = Color(0xFF1E293B)
val SurfaceBorderHighlight = Color(0xFF334155)

val AccentBlue = Color(0xFF2563EB)
val AccentBlueLight = Color(0xFF3B82F6)
val AccentCyanGlow = Color(0xFF06B6D4)

val ConnectedGreen = Color(0xFF10B981)
val ConnectedGreenDark = Color(0xFF064E3B)
val ConnectedGreenLight = Color(0xFF34D399)

val DisconnectRed = Color(0xFFEF4444)
val DisconnectRedDark = Color(0xFF7F1D1D)

val WarningYellow = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val CardBackground = Color(0xFF0F172A)
val CardBackgroundElevated = Color(0xFF172239)
val InputFieldBackground = Color(0xFF0B1324)
val BottomNavBackground = Color(0xFF0A0F1D)
