package com.example.ui.screens

import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/** Visual states of the Connect control. They are derived from the real VPN service state. */
internal enum class ConnectVisual { READY, CONNECTING, RECONNECTING, CONNECTED, DISCONNECTING, ERROR }

private val NeonBlue = Color(0xFF168BFF)
private val NeonCyan = Color(0xFF00D9FF)
private val NeonViolet = Color(0xFF873BFF)
private val NeonGreen = Color(0xFF00F5A0)
private val NeonRed = Color(0xFFFF365D)

private class AnimPalette(val a: State<Color>, val b: State<Color>, val c: State<Color>)

@Composable
private fun rememberPalette(v: ConnectVisual): AnimPalette {
    val (ta, tb, tc) = when (v) {
        ConnectVisual.READY, ConnectVisual.DISCONNECTING -> Triple(NeonCyan, NeonBlue, NeonViolet)
        ConnectVisual.CONNECTING, ConnectVisual.RECONNECTING -> Triple(NeonCyan, NeonBlue, Color(0xFF3FB6FF))
        ConnectVisual.CONNECTED -> Triple(NeonGreen, Color(0xFF00D98B), Color(0xFF3DFFB5))
        ConnectVisual.ERROR -> Triple(NeonRed, Color(0xFFFF5C7C), Color(0xFFC81E47))
    }
    return AnimPalette(
        animateColorAsState(ta, tween(350), label = "pa"),
        animateColorAsState(tb, tween(350), label = "pb"),
        animateColorAsState(tc, tween(350), label = "pc")
    )
}

/** True when the user switched system animations off (animator duration scale = 0). */
@Composable
private fun rememberReduceMotion(): Boolean {
    val ctx = LocalContext.current
    return remember {
        runCatching {
            Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        }.getOrDefault(false)
    }
}

/**
 * The slide-to-connect control: swipe the raised power module from left to right to connect,
 * and back from right to left to disconnect (or to cancel a running attempt).
 * All decorative loops are cheap (a few paths per frame) and stop automatically when the app is not
 * on screen, because Compose only animates while frames are being drawn.
 */
@Composable
internal fun ConnectHero(visual: ConnectVisual, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val reduce = rememberReduceMotion()
    val palette = rememberPalette(visual)
    val connecting = visual == ConnectVisual.CONNECTING || visual == ConnectVisual.RECONNECTING
    val connectingA = animateFloatAsState(if (connecting) 1f else 0f, tween(450), label = "connA")

    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        HexButton(
            visual = visual,
            palette = palette,
            connectingA = connectingA,
            reduce = reduce,
            width = minOf(maxWidth * 0.92f, 380.dp),
            onActivate = onClick
        )
    }
}

/** Thumb position for a state: 0 = left (off), 1 = right (on). */
private fun thumbTarget(v: ConnectVisual): Float = when (v) {
    ConnectVisual.CONNECTING, ConnectVisual.RECONNECTING, ConnectVisual.CONNECTED -> 1f
    else -> 0f
}

private fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t

private enum class IconKind { POWER, SHIELD, WARNING }

@Composable
private fun HexButton(
    visual: ConnectVisual,
    palette: AnimPalette,
    connectingA: State<Float>,
    reduce: Boolean,
    width: Dp,
    onActivate: () -> Unit
) {
    val height = width / 2.55f
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val currentVisual by rememberUpdatedState(visual)
    val currentOnActivate by rememberUpdatedState(onActivate)

    // thumb (power module) position: 0 = left, 1 = right
    val thumb = remember { Animatable(thumbTarget(visual)) }
    var dragging by remember { mutableStateOf(false) }
    var tapPressed by remember { mutableStateOf(false) }
    val pressed = dragging || tapPressed
    LaunchedEffect(visual) {
        if (!dragging) thumb.animateTo(thumbTarget(visual), tween(350, easing = FastOutSlowInEasing))
    }
    // chevrons / label live on the free side of the track
    val onSide = visual == ConnectVisual.CONNECTING || visual == ConnectVisual.RECONNECTING || visual == ConnectVisual.CONNECTED
    val sideS = animateFloatAsState(if (onSide) 1f else 0f, tween(300), label = "side")

    val moduleH = height - 6.dp
    val modW = moduleH * 1.08f
    val travel = width - 6.dp - modW
    val travelPx = with(density) { travel.toPx() }

    val pressScale by animateFloatAsState(if (pressed) 0.965f else 1f, tween(130), label = "press")
    val pressGlow = animateFloatAsState(if (pressed) 0.45f else 0f, tween(130), label = "pressGlow")

    val baseGlow = animateFloatAsState(
        when (visual) {
            ConnectVisual.READY -> 0.55f
            ConnectVisual.CONNECTING -> 0.95f
            ConnectVisual.RECONNECTING -> 0.9f
            ConnectVisual.CONNECTED -> 0.65f
            ConnectVisual.DISCONNECTING -> 0.45f
            ConnectVisual.ERROR -> 0.75f
        },
        tween(450), label = "glow"
    )
    val busy = visual == ConnectVisual.CONNECTING || visual == ConnectVisual.RECONNECTING || visual == ConnectVisual.DISCONNECTING
    val progressA = animateFloatAsState(if (busy) 1f else 0f, tween(250), label = "progA")

    val t = rememberInfiniteTransition(label = "btn")
    val breath = t.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breath")
    val slowPhase = t.animateFloat(0f, 1f, infiniteRepeatable(tween(4600, easing = LinearEasing)), label = "slow")
    val fastPhase = t.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "fast")
    val wavePhase = t.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "wave")
    val spin = t.animateFloat(0f, 1f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "spin")

    // One confirmation pulse when the connection succeeds or fails
    val pulse = remember { Animatable(0f) }
    LaunchedEffect(visual) {
        if (visual == ConnectVisual.CONNECTED || visual == ConnectVisual.ERROR) {
            pulse.snapTo(0f)
            pulse.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        } else {
            pulse.snapTo(0f)
        }
    }

    val label = when (visual) {
        ConnectVisual.READY -> "CONNECT"
        ConnectVisual.CONNECTING -> "CONNECTING..."
        ConnectVisual.RECONNECTING -> "RECONNECTING..."
        ConnectVisual.CONNECTED -> "DISCONNECT"
        ConnectVisual.DISCONNECTING -> "DISCONNECTING..."
        ConnectVisual.ERROR -> "RETRY"
    }
    val stateText = when (visual) {
        ConnectVisual.READY -> "Disconnected. Swipe right, or double tap, to connect"
        ConnectVisual.CONNECTING -> "Connecting. Swipe left, or double tap, to cancel"
        ConnectVisual.RECONNECTING -> "Reconnecting. Swipe left, or double tap, to cancel"
        ConnectVisual.CONNECTED -> "Connected. Swipe left, or double tap, to disconnect"
        ConnectVisual.DISCONNECTING -> "Disconnecting"
        ConnectVisual.ERROR -> "Connection failed. Swipe right, or double tap, to retry"
    }

    var heldIcon by remember { mutableStateOf(IconKind.POWER) }
    val iconKind = when (visual) {
        ConnectVisual.CONNECTED -> IconKind.SHIELD
        ConnectVisual.ERROR -> IconKind.WARNING
        ConnectVisual.DISCONNECTING -> heldIcon
        else -> IconKind.POWER
    }
    SideEffect { if (visual != ConnectVisual.DISCONNECTING) heldIcon = iconKind }

    val rm = if (reduce) 0f else 1f

    Box(
        modifier = Modifier
            .size(width, height)
            .scale(pressScale)
            .semantics(mergeDescendants = true) {
                contentDescription = "VPN switch: $label"
                stateDescription = stateText
                role = Role.Switch
                onClick(label = "Toggle VPN") {
                    if (currentVisual != ConnectVisual.DISCONNECTING) currentOnActivate()
                    true
                }
            }
            // tap: nudge the thumb to show that this is a swipe control
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        tapPressed = true
                        tryAwaitRelease()
                        tapPressed = false
                    },
                    onTap = {
                        val v = currentVisual
                        if (v == ConnectVisual.READY || v == ConnectVisual.ERROR) {
                            scope.launch {
                                thumb.animateTo(0.22f, tween(180, easing = FastOutSlowInEasing))
                                thumb.animateTo(0f, tween(260, easing = FastOutSlowInEasing))
                            }
                        }
                    }
                )
            }
            // swipe: right = connect, left = disconnect / cancel
            .pointerInput(travelPx) {
                val finish: () -> Unit = finish@{
                    if (!dragging) return@finish
                    dragging = false
                    val v = currentVisual
                    val fromOn = thumbTarget(v) == 1f
                    val activate = if (fromOn) thumb.value < 0.4f else thumb.value > 0.6f
                    scope.launch {
                        if (activate) {
                            thumb.animateTo(if (fromOn) 0f else 1f, tween(160, easing = FastOutSlowInEasing))
                            currentOnActivate()
                            // safety: if the service never reacted, put the thumb back where the state says
                            delay(1500)
                            if (currentVisual == v) {
                                thumb.animateTo(thumbTarget(v), tween(300, easing = FastOutSlowInEasing))
                            }
                        } else {
                            thumb.animateTo(thumbTarget(v), tween(220, easing = FastOutSlowInEasing))
                        }
                    }
                }
                detectHorizontalDragGestures(
                    onDragStart = {
                        if (currentVisual != ConnectVisual.DISCONNECTING && travelPx > 0f) dragging = true
                    },
                    onDragEnd = { finish() },
                    onDragCancel = { finish() },
                    onHorizontalDrag = { change, dx ->
                        if (dragging) {
                            change.consume()
                            val np = (thumb.value + dx / travelPx).coerceIn(0f, 1f)
                            scope.launch { thumb.snapTo(np) }
                        }
                    }
                )
            }
            .drawWithCache {
                val w = size.width
                val h = size.height
                val pad = 3.dp.toPx()
                val hh = h - 2f * pad
                val mw = hh * 1.08f
                val modPts = listOf(
                    Offset(pad + mw * 0.25f, pad), Offset(pad + mw * 0.75f, pad),
                    Offset(pad + mw, pad + hh * 0.5f),
                    Offset(pad + mw * 0.75f, pad + hh), Offset(pad + mw * 0.25f, pad + hh),
                    Offset(pad, pad + hh * 0.5f)
                )
                val modCenter = Offset(pad + mw / 2f, pad + hh / 2f)
                val modPath = roundedPoly(modPts, hh * 0.09f)
                val innerPath = roundedPoly(scalePoly(modPts, modCenter, 0.76f), hh * 0.07f)
                val topY = pad + hh * 0.13f
                val botY = pad + hh * 0.87f
                val midY = pad + hh * 0.5f
                val tipX = w - pad
                val bevel = hh * 0.32f
                val panelPath = roundedPoly(
                    listOf(
                        Offset(pad + bevel, topY), Offset(tipX - bevel, topY), Offset(tipX, midY),
                        Offset(tipX - bevel, botY), Offset(pad + bevel, botY), Offset(pad + hh * 0.02f, midY)
                    ),
                    hh * 0.08f
                )
                val travelDraw = w - 2f * pad - mw
                val measure = PathMeasure()
                measure.setPath(panelPath, true)
                val perimeter = measure.length
                val seg = Path()
                val edgeW = 1.8.dp.toPx()
                val modEdgeW = 2.2.dp.toPx()
                val panelGlowW = floatArrayOf(14.dp.toPx(), 9.dp.toPx(), 5.dp.toPx())
                val modGlowW = floatArrayOf(12.dp.toPx(), 7.dp.toPx(), 4.dp.toPx())
                val glowA = floatArrayOf(0.05f, 0.08f, 0.14f)
                val progW = 2.5.dp.toPx()
                val rr = hh * 0.325f

                onDrawBehind {
                    val ca = palette.a.value
                    val cb = palette.b.value
                    val cc = palette.c.value
                    val breathing = if (visual == ConnectVisual.READY || visual == ConnectVisual.CONNECTED) 0.10f * breath.value * rm else 0f
                    val glow = (baseGlow.value + breathing + pressGlow.value + 0.7f * sin(pulse.value * PI.toFloat())).coerceIn(0f, 1.6f)

                    val edge = Brush.horizontalGradient(listOf(ca, cb, cc), startX = 0f, endX = w)
                    val modEdge = Brush.linearGradient(listOf(ca, cb, cc), start = Offset(pad, pad), end = Offset(pad + mw, pad + hh))

                    // outer neon glow (stacked strokes)
                    for (i in 0 until 3) {
                        drawPath(panelPath, edge, alpha = (glowA[i] * glow).coerceAtMost(1f), style = Stroke(panelGlowW[i], join = StrokeJoin.Round))
                    }

                    // soft energy wave while connecting
                    val cA = connectingA.value
                    if (cA > 0.01f && !reduce) {
                        val p = wavePhase.value
                        drawPath(panelPath, edge, alpha = 0.22f * (1f - p) * cA, style = Stroke(2.dp.toPx() + 16.dp.toPx() * p, join = StrokeJoin.Round))
                    }

                    // main action panel
                    drawPath(
                        panelPath,
                        Brush.horizontalGradient(listOf(Color(0xE60A1640), Color(0xE6070F30), Color(0xE60E0F45)), startX = 0f, endX = w)
                    )
                    clipPath(panelPath) {
                        drawRect(
                            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.Transparent), startY = topY, endY = midY),
                            topLeft = Offset(0f, topY), size = Size(w, midY - topY)
                        )
                        drawRect(
                            Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.25f)), startY = midY, endY = botY),
                            topLeft = Offset(0f, midY), size = Size(w, botY - midY)
                        )
                    }
                    drawPath(panelPath, edge, style = Stroke(edgeW, join = StrokeJoin.Round))

                    // travelling light on the border
                    if (!reduce) {
                        when (visual) {
                            ConnectVisual.READY -> {
                                val ph = slowPhase.value
                                if (ph < 0.4f) {
                                    val pos = ph / 0.4f
                                    drawSweep(measure, perimeter, seg, pos, 0.14f, Color.White, sin(pos * PI.toFloat()) * 0.75f, 2.2.dp.toPx())
                                }
                            }
                            ConnectVisual.CONNECTING, ConnectVisual.RECONNECTING ->
                                drawSweep(measure, perimeter, seg, fastPhase.value, 0.22f, ca, 0.95f, 3.dp.toPx())
                            ConnectVisual.DISCONNECTING ->
                                drawSweep(measure, perimeter, seg, fastPhase.value, 0.18f, cb, 0.5f, 2.5.dp.toPx())
                            ConnectVisual.CONNECTED -> {
                                val pp = pulse.value
                                if (pp > 0.001f && pp < 0.999f) {
                                    drawSweep(measure, perimeter, seg, pp, 0.3f, Color.White, sin(pp * PI.toFloat()), 3.dp.toPx())
                                } else {
                                    val ph = slowPhase.value
                                    if (ph < 0.4f) {
                                        val pos = ph / 0.4f
                                        drawSweep(measure, perimeter, seg, pos, 0.12f, Color.White, sin(pos * PI.toFloat()) * 0.35f, 2.dp.toPx())
                                    }
                                }
                            }
                            ConnectVisual.ERROR -> Unit
                        }
                    }

                    translate(left = thumb.value * travelDraw) {
                    // neon glow follows the module while it slides
                    for (i in 0 until 3) {
                        drawPath(modPath, modEdge, alpha = (glowA[i] * 1.2f * glow).coerceAtMost(1f), style = Stroke(modGlowW[i], join = StrokeJoin.Round))
                    }
                    // raised power module (layered glass hexagon)
                    drawPath(
                        modPath,
                        Brush.radialGradient(
                            listOf(cb.copy(alpha = 0.95f), Color(0xFF061046)),
                            center = Offset(modCenter.x - mw * 0.15f, modCenter.y - hh * 0.2f), radius = mw * 0.75f
                        )
                    )
                    clipPath(modPath) {
                        drawRect(
                            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.28f), Color.Transparent), startY = pad, endY = pad + hh * 0.45f),
                            topLeft = Offset(pad, pad), size = Size(mw, hh * 0.45f)
                        )
                    }
                    drawPath(
                        innerPath,
                        Brush.verticalGradient(listOf(Color(0xFF0A1A66), Color(0xFF040A2C)), startY = pad, endY = pad + hh)
                    )
                    drawPath(innerPath, modEdge, alpha = 0.55f, style = Stroke(1.dp.toPx(), join = StrokeJoin.Round))
                    drawPath(modPath, modEdge, style = Stroke(modEdgeW, join = StrokeJoin.Round))

                    // small progress ring inside the module while working
                    val pa = progressA.value
                    if (pa > 0.01f) {
                        drawCircle(Color.White.copy(alpha = 0.08f * pa), rr, modCenter, style = Stroke(progW))
                        rotate(spin.value * 360f * rm, modCenter) {
                            drawArc(
                                Brush.sweepGradient(listOf(Color.Transparent, ca, Color.White), modCenter),
                                startAngle = 0f, sweepAngle = 270f, useCenter = false,
                                topLeft = Offset(modCenter.x - rr, modCenter.y - rr), size = Size(rr * 2f, rr * 2f),
                                alpha = pa, style = Stroke(progW, cap = StrokeCap.Round)
                            )
                        }
                    }
                    }
                }
            }
    ) {
        // fades while the thumb slides over the label / chevrons
        fun coverAlpha(): Float {
            val p = thumb.value
            return lerpF(1f - p * 1.4f, 1f - (1f - p) * 1.4f, sideS.value).coerceIn(0f, 1f)
        }

        // power module (the thumb): slides along the track
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .padding(start = 3.dp)
                .size(modW, moduleH)
                .offset { IntOffset((thumb.value * travelPx).roundToInt(), 0) },
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = iconKind, animationSpec = tween(240), label = "icon") { kind ->
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    when (kind) {
                        IconKind.POWER -> Icon(Icons.Default.PowerSettingsNew, null, tint = Color.White, modifier = Modifier.size(height * 0.40f))
                        IconKind.SHIELD -> Icon(Icons.Default.VerifiedUser, null, tint = Color.White, modifier = Modifier.size(height * 0.40f))
                        IconKind.WARNING -> Icon(Icons.Default.Warning, null, tint = Color(0xFFFFB3C0), modifier = Modifier.size(height * 0.40f))
                    }
                }
            }
        }

        // label: on the free side of the track
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .width(width - modW - 11.dp - height * 0.48f)
                .fillMaxHeight()
                .offset {
                    IntOffset(
                        lerpF((11.dp + modW).toPx(), (height * 0.48f).toPx(), sideS.value).roundToInt(), 0
                    )
                }
                .graphicsLayer { alpha = coverAlpha() },
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = label,
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(180)) },
                label = "label"
            ) { text ->
                val sizeFactor = when {
                    text.length <= 7 -> 0.17f
                    text.length <= 10 -> 0.125f
                    text.length <= 13 -> 0.10f
                    else -> 0.085f
                }
                Text(
                    text,
                    color = Color.White,
                    fontSize = (height.value * sizeFactor).sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }

        // chevrons point in the swipe direction: right to connect, left to disconnect
        Chevrons(
            palette = palette,
            visual = visual,
            fast = fastPhase,
            slow = slowPhase,
            side = sideS,
            reduce = reduce,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .size(height * 0.24f, height * 0.26f)
                .offset {
                    IntOffset(
                        lerpF((width - height * 0.48f).toPx(), (height * 0.24f).toPx(), sideS.value).roundToInt(), 0
                    )
                }
                .graphicsLayer { alpha = coverAlpha() }
        )
    }
}

@Composable
private fun Chevrons(
    palette: AnimPalette,
    visual: ConnectVisual,
    fast: State<Float>,
    slow: State<Float>,
    side: State<Float>,
    reduce: Boolean,
    modifier: Modifier
) {
    Canvas(modifier) {
        val s = side.value
        val flip = s > 0.5f
        val fade = abs(s - 0.5f) * 2f // fades out/in while the chevrons change side
        val moving = (visual == ConnectVisual.CONNECTING || visual == ConnectVisual.RECONNECTING) && !reduce
        val dir = if (flip) -1f else 1f
        val shift = if (moving) fast.value * 4.dp.toPx() * dir else 0f
        val sw = 3.dp.toPx()
        val cw = size.width * 0.38f
        for (k in 0..1) {
            val x0 = k * size.width * 0.5f
            val tipX = x0 + cw
            fun mx(x: Float) = (if (flip) size.width - x else x) + shift
            val path = Path().apply {
                moveTo(mx(x0), size.height * 0.1f)
                lineTo(mx(tipX), size.height * 0.5f)
                lineTo(mx(x0), size.height * 0.9f)
            }
            val base = when {
                moving -> 0.45f + 0.55f * sin(fast.value * PI.toFloat())
                visual == ConnectVisual.READY && !reduce -> 0.6f + 0.4f * sin(slow.value * 2f * PI.toFloat() - k * 0.9f)
                else -> 1f
            }
            val col = if (k == 0) palette.b.value else palette.c.value
            drawPath(path, col.copy(alpha = (base * fade).coerceIn(0f, 1f)), style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

private fun DrawScope.drawSweep(
    measure: PathMeasure, len: Float, seg: Path,
    pos: Float, frac: Float, color: Color, alpha: Float, width: Float
) {
    if (alpha <= 0.01f || len <= 0f) return
    val start = (pos - floor(pos)) * len
    val end = start + len * frac
    seg.reset()
    if (end <= len) {
        measure.getSegment(start, end, seg, true)
    } else {
        measure.getSegment(start, len, seg, true)
        measure.getSegment(0f, end - len, seg, true)
    }
    drawPath(seg, color, alpha = alpha * 0.35f, style = Stroke(width * 3.5f, cap = StrokeCap.Round))
    drawPath(seg, color, alpha = alpha, style = Stroke(width, cap = StrokeCap.Round))
}

/** Polygon with softly rounded corners. */
private fun roundedPoly(pts: List<Offset>, radius: Float): Path {
    val path = Path()
    val n = pts.size
    for (i in 0 until n) {
        val p0 = pts[(i + n - 1) % n]
        val p1 = pts[i]
        val p2 = pts[(i + 1) % n]
        val v1 = p0 - p1
        val v2 = p2 - p1
        val l1 = v1.getDistance()
        val l2 = v2.getDistance()
        val r = minOf(radius, l1 / 2f, l2 / 2f)
        val a = p1 + v1 * (r / l1)
        val b = p1 + v2 * (r / l2)
        if (i == 0) path.moveTo(a.x, a.y) else path.lineTo(a.x, a.y)
        path.quadraticBezierTo(p1.x, p1.y, b.x, b.y)
    }
    path.close()
    return path
}

private fun scalePoly(pts: List<Offset>, center: Offset, s: Float): List<Offset> =
    pts.map { center + (it - center) * s }
