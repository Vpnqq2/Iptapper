package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.local.ConfigRepository
import com.example.data.local.SettingsRepository
import com.example.core.logs.LogManager
import com.example.push.AppMessagingService
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.security.Security

class SshTunnelApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var configRepository: ConfigRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Android ships a stripped-down "BC" provider without X25519/Ed25519, which makes sshj fail with
        // "no such algorithm: X25519 for provider BC". Replace it with the full BouncyCastle library
        // before any SSH class is used.
        try {
            Security.removeProvider(BouncyCastleProvider.PROVIDER_NAME)
            Security.insertProviderAt(BouncyCastleProvider(), 1)
        } catch (e: Exception) {
            LogManager.w("Could not install BouncyCastle provider: ${e.message}")
        }

        database = AppDatabase.getInstance(this)
        settingsRepository = SettingsRepository(this)
        configRepository = ConfigRepository(database.tunnelConfigDao(), this)

        // Push notifications (needs app/google-services.json; without it Firebase stays off and the app still runs)
        AppMessagingService.ensureChannel(this)
        try {
            if (FirebaseApp.getApps(this).isNotEmpty()) {
                FirebaseMessaging.getInstance().subscribeToTopic("all")
            } else {
                LogManager.w("Firebase not configured (google-services.json missing): push disabled")
            }
        } catch (e: Exception) {
            LogManager.w("FCM setup failed: ${e.message}")
        }

        LogManager.i("SSH Tunnel application initialized")
    }

    companion object {
        lateinit var instance: SshTunnelApp
            private set
    }
}
