package com.example.ads

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.BuildConfig
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

/** Standard 320x50 AdMob banner. The 50dp slot is reserved so the layout does not jump when the ad loads. */
@Composable
fun AdBanner(modifier: Modifier = Modifier) {
    if (!AdManager.adsReady) {
        Spacer(modifier.height(50.dp))
        return
    }
    val context = LocalContext.current
    val adView = remember {
        AdView(context).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = BuildConfig.ADMOB_BANNER_ID
            loadAd(AdRequest.Builder().build())
        }
    }
    AndroidView(
        modifier = modifier.height(50.dp),
        factory = { adView },
        onRelease = { it.destroy() }
    )
}
