#!/usr/bin/env python3
"""
Encrypts server-list URLs for app/src/main/java/com/example/data/remote/RemoteUrls.kt

Usage:
    pip install cryptography
    python3 tools/encrypt_urls.py https://example.com/servers.json https://mirror.example.com/servers.json

Paste the printed lines into the `blobs` list in RemoteUrls.kt (first = primary, rest = fallbacks).
The key is derived from AppSecret.kt (same derivation as the app), so keep both files in sync.
"""
import base64, hashlib, os, re, sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SECRET = os.path.join(ROOT, "app/src/main/java/com/example/data/backup/AppSecret.kt")
PURPOSE = b"urls-v1"

def material() -> bytes:
    src = open(SECRET).read()
    arr = {m.group(1): [int(x, 16) for x in re.findall(r"0x([0-9A-Fa-f]{2})", m.group(2))]
           for m in re.finditer(r"val ([am]\d) = intArrayOf\(([^)]*)\)", src)}
    out = bytearray()
    for p in range(4):
        out += bytes(a ^ b for a, b in zip(arr[f"a{p}"], arr[f"m{p}"]))
    return bytes(out)

def encrypt(url: str) -> str:
    key = hashlib.sha256(material() + PURPOSE).digest()
    iv = os.urandom(12)
    return base64.b64encode(iv + AESGCM(key).encrypt(iv, url.encode(), None)).decode()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    for u in sys.argv[1:]:
        if not u.startswith("https://"):
            sys.exit(f"Refusing non-HTTPS url: {u}")
        print(f'        "{encrypt(u)}",')
